from pathlib import Path

import numpy as np
import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("mujoco")
pytest.importorskip("onnxruntime")
pytest.importorskip("rsl_rl")

from wheelleg import tensor_training as tensor  # noqa: E402
from wheelleg import training_rewards as numpy_terms  # noqa: E402
from wheelleg.mujoco_train import MujocoTrainEnv, load_training_profile  # noqa: E402
from wheelleg.scut_policy import scut_lowlevel  # noqa: E402

PROFILE = Path(__file__).resolve().parents[1] / "config/policies/srm_scut/policy_meta.yaml"


def test_srm_observation_joint_order_and_physics_rate():
    profile = load_training_profile(PROFILE)
    env = MujocoTrainEnv(profile, num_envs=2)
    try:
        # Only manipulate state and inspect the contract. No PPO or optimizer is constructed.
        env.qpos[:, env.qadr[:6]] = [0.1, 0.2, 0.3, 0.4, 17, 19]
        env.qvel[:, env.vadr[:6]] = [1, 2, 3, 4, 5, 6]
        env.previous[:] = np.arange(6)
        obs, _ = env.get_observations()
        np.testing.assert_allclose(obs[0, 10:16], [0.1, 0.2, 0, 0.3, 0.4, 0], atol=1e-6)
        np.testing.assert_allclose(obs[0, 16:22], [0.1, 0.2, 0.5, 0.3, 0.4, 0.6], atol=1e-6)
        np.testing.assert_allclose(obs[0, 22:28], np.arange(6))
        np.testing.assert_array_equal(obs[0, 28:], [1, 0, 0, 0, 0, 0, 0])
        assert env.step_dt == 0.01
        assert env.model.opt.timestep == 0.002
        env.reset()
        env.step(torch.zeros((2, 6)))
        np.testing.assert_allclose(env.state[:, 0], 0.01, atol=1e-12)
        assert env.total_physics_faults == 0
    finally:
        env.close()


def test_torch_physics_matches_numpy_reference():
    cfg = load_training_profile(PROFILE).physics
    tcfg = tensor.physics_tensors(cfg, "cpu")
    rng = np.random.default_rng(3)
    q, dq = rng.uniform(-0.5, 0.5, (32, 8)), rng.uniform(-20, 20, (32, 8))
    action = rng.uniform(-2, 2, (32, 6))
    effort, rate = np.zeros((32, 4)), np.zeros((32, 4))
    te, tr = torch.zeros((32, 4)), torch.zeros((32, 4))
    for step in range(10):
        first = np.full(32, step == 0)
        force, effort, rate = scut_lowlevel(cfg, q, dq, action, effort, rate, first, 0.002)
        tf, te, tr = tensor.lowlevel(
            tcfg,
            torch.tensor(q, dtype=torch.float32),
            torch.tensor(dq, dtype=torch.float32),
            torch.tensor(action, dtype=torch.float32),
            te,
            tr,
            torch.from_numpy(first),
            0.002,
        )
        np.testing.assert_allclose(tf.numpy(), force, atol=2e-4, rtol=2e-5)


def test_tunnel_requires_full_airborne_crossing_then_ground_landing():
    radii = torch.tensor([0.1, 0.1])
    flying = torch.tensor([[[0.7, -0.2, 0.6], [0.8, 0.2, 0.6]]])
    previous = torch.tensor([0.4])
    airborne = torch.tensor([[False, False]])
    assert tensor.clear_roof(flying, radii, previous, airborne, 0.45, 0.35, 1.4).item()
    np.testing.assert_array_equal(
        numpy_terms.clear_roof(flying.numpy(), radii.numpy(), previous.numpy(), airborne.numpy(), 0.45, 0.35, 1.4),
        [True],
    )
    ground_crossing = flying.clone()
    ground_crossing[:, :, 2] = 0.1
    assert not tensor.clear_roof(ground_crossing, radii, previous, airborne, 0.45, 0.35, 1.4).item()
    bypass = flying.clone()
    bypass[:, :, 1] += 2
    assert not tensor.clear_roof(bypass, radii, previous, airborne, 0.45, 0.35, 1.4).item()
    partial = flying.clone()
    partial[:, 0, 0] = 0.4
    assert not tensor.clear_roof(partial, radii, previous, airborne, 0.45, 0.35, 1.4).item()
    landing = torch.tensor([[[1.5, -0.2, 0.1], [1.8, 0.2, 0.1]]])
    assert tensor.tunnel_success(landing, radii, ~airborne, torch.tensor([False]), (1.1, 3.1), (-0.7, 0.7)).item()
    assert not tensor.tunnel_success(landing, radii, ~airborne, torch.tensor([True]), (1.1, 3.1), (-0.7, 0.7)).item()
    assert not tensor.tunnel_success(landing, radii, airborne, torch.tensor([False]), (1.1, 3.1), (-0.7, 0.7)).item()


def test_timeout_bootstrap_uses_terminal_value_only():
    rewards = torch.tensor([1.0, 1.0, 1.0])
    result = tensor.bootstrap_timeout(
        rewards, torch.tensor([10.0, 20.0, 30.0]), torch.tensor([True, False, False]), 0.99
    )
    torch.testing.assert_close(result, torch.tensor([10.9, 1.0, 1.0]))


def test_tensor_and_numpy_observations_agree():
    profile = load_training_profile(PROFILE)
    env = MujocoTrainEnv(profile, num_envs=2)
    try:
        env.previous[:] = np.arange(6)
        obs, _ = env.get_observations()
        q = env.qpos[:, env.qadr[:6]][:, env.permutation].copy()
        q[:, profile.settings["wheel_indices"]] = 0
        actual = tensor.observation(
            profile.policy,
            torch.tensor(env.command, dtype=torch.float32),
            torch.tensor(env.height_command, dtype=torch.float32),
            torch.zeros((2, 3)),
            torch.tensor([[0.0, 0.0, -1.0], [0.0, 0.0, -1.0]]),
            torch.tensor(q, dtype=torch.float32),
            torch.zeros((2, 6)),
            torch.tensor(env.previous, dtype=torch.float32),
            torch.tensor(profile.physics.normal_mode).repeat(2, 1),
        )
        torch.testing.assert_close(actual, obs)
    finally:
        env.close()


def test_no_fork_is_body_frame_and_has_deadband():
    wheels = torch.tensor([[[0.2, 0.2, 0.0], [0.0, -0.2, 0.0]]])
    identity = torch.tensor([[1.0, 0.0, 0.0, 0.0]])
    gap = tensor.wheel_forward_offset(wheels, identity)
    torch.testing.assert_close(gap, torch.tensor([0.2]))
    # Rotate both the body and wheel centers by yaw=90 degrees and translate in world.
    rotated = wheels.clone()
    rotated[..., 0], rotated[..., 1] = -wheels[..., 1], wheels[..., 0]
    rotated += torch.tensor([20.0, -15.0, 2.0])
    quat = torch.tensor([[2**-0.5, 0.0, 0.0, 2**-0.5]])
    torch.testing.assert_close(tensor.wheel_forward_offset(rotated, quat), gap, atol=2e-6, rtol=1e-5)
    torch.testing.assert_close(
        tensor.no_fork(torch.tensor([0.0, 0.05, 0.15, -0.15]), 0.05, 5), torch.tensor([0.0, 0.0, 0.25, 0.25])
    )


def test_diagnostics_measure_errors_and_channel_clipping():
    commands = torch.tensor([[0.0, 0.0, 0.0], [0.6, 0.0, -0.6]])
    velocity = torch.tensor([[0.0, 0.0, 0.0], [0.1, 0.0, 0.0]])
    angular = torch.zeros_like(velocity)
    actions = torch.tensor([[0.0, 4.0, 0.0, 0.0, 0.0, 0.0], [0.0, 0.0, -4.0, 0.0, 0.0, 0.0]])
    result = tensor.motion_diagnostics(velocity, angular, commands, actions, 3.0)
    assert result["Metrics/moving_vx_rmse_m_s"].item() == pytest.approx(0.5)
    assert result["Metrics/moving_yaw_rmse_rad_s"].item() == pytest.approx(0.6)
    assert result["Metrics/standing_vx_rmse_m_s"].item() == 0
    assert result["Metrics/action_clip_fraction"].item() == pytest.approx(2 / 12)
    assert result["Metrics/action_clip_channel_1"].item() == 0.5
    empty = tensor.motion_diagnostics(velocity, angular, torch.zeros_like(commands), actions, 3.0)
    assert all(torch.isfinite(value) for value in empty.values())
    assert empty["Metrics/moving_sample_fraction"].item() == 0


def test_flat_boundary_allows_ten_second_max_speed():
    cfg = load_training_profile(PROFILE).settings
    flat = cfg["stages"]["flat"]
    assert flat["spawn_x_m"] == 0
    for sign in (-1, 1):
        end = flat["spawn_x_m"] + sign * max(abs(v) for v in cfg["command_vx_range_m_s"]) * cfg["episode_seconds"]
        assert abs(end) < flat["half_extent_m"]
    assert flat["env_spacing_m"] > 2 * flat["half_extent_m"]
