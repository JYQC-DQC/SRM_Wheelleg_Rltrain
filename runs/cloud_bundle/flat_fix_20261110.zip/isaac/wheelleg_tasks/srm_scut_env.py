"""Cloud-only Isaac Lab 2.3.2 task. Import only after AppLauncher starts Isaac Sim.

Uses the unchanged SCUT WheelBipe_V14_2_CFG asset; task structure follows Isaac Lab's DirectRLEnv workflow.
No SCUT policy weights are read by this environment.
"""

import math
from pathlib import Path

import isaaclab.sim as sim_utils
import numpy as np
import torch
from agent_world.assets.wheelbipe_V14_2 import Wheelbipe_V14_2_CFG
from isaaclab.assets import Articulation
from isaaclab.envs import DirectRLEnv, DirectRLEnvCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import ContactSensor, ContactSensorCfg
from isaaclab.sim import SimulationCfg
from isaaclab.utils import configclass
from isaaclab.utils.math import quat_from_euler_xyz, sample_uniform

from wheelleg import tensor_training as terms
from wheelleg.mujoco_train import TrainingProfile


@configclass
class SrmScutEnvCfg(DirectRLEnvCfg):
    action_space = 6
    observation_space = 35
    state_space = 0
    decimation = 1  # Replaced from the profile before construction.
    sim: SimulationCfg = SimulationCfg()
    scene: InteractiveSceneCfg = InteractiveSceneCfg(num_envs=1, env_spacing=1.0, replicate_physics=True)


def make_env_cfg(profile: TrainingProfile, num_envs: int, device: str) -> SrmScutEnvCfg:
    cfg = SrmScutEnvCfg()
    cfg.seed = profile.settings["seed"]
    cfg.decimation = profile.settings["control_hz"] // profile.settings["policy_hz"]
    cfg.episode_length_s = profile.settings["episode_seconds"]
    cfg.sim.dt = 1 / profile.settings["control_hz"]
    cfg.sim.device = device
    cfg.sim.render_interval = cfg.decimation
    cfg.scene.num_envs = num_envs
    cfg.scene.env_spacing = profile.settings["env_spacing_m"]
    return cfg


class SrmScutEnv(DirectRLEnv):
    def __init__(self, cfg: SrmScutEnvCfg, profile: TrainingProfile, stage: str = "flat", **kwargs):
        self.profile, self.settings = profile, profile.settings
        self.stage = self.settings["stages"][stage]
        self.bounds_names = list(self.settings["body_bounds_m"])
        # Resolve robot asset before cloning; references remain external and unchanged.
        self.robot_cfg = Wheelbipe_V14_2_CFG.copy()
        self.robot_cfg.prim_path = "/World/envs/env_.*/Robot"
        if not Path(self.robot_cfg.spawn.usd_path).is_file():
            raise FileNotFoundError(self.robot_cfg.spawn.usd_path)
        # Low-level forces already contain PD/damping. Remove those terms from active actuators to avoid double PD.
        for group in ["legs_act", "wheel", "spring"]:
            self.robot_cfg.actuators[group].stiffness = 0.0
            self.robot_cfg.actuators[group].damping = 0.0
        self.robot_cfg.actuators["legs_act"].effort_limit = profile.physics.actuator["actuator_output_limit"]
        self.robot_cfg.actuators["spring"].effort_limit = max(profile.physics.effort_max[6:])
        if stage == "flat":
            cfg.scene.env_spacing = self.stage["env_spacing_m"]
        super().__init__(cfg, **kwargs)
        self.source_joints, found = self.robot.find_joints(list(profile.physics.joint_names), preserve_order=True)
        if tuple(found) != profile.physics.joint_names:
            raise ValueError(f"USD joint mapping mismatch: {found}")
        self.srm_joints = [self.source_joints[i] for i in self.settings["source_to_srm"]]
        self.inverse = torch.tensor(np.argsort(self.settings["source_to_srm"]), device=self.device)
        self.bound_bodies, found = self.robot.find_bodies(self.bounds_names, preserve_order=True)
        if found != self.bounds_names:
            raise ValueError("USD body frames do not match the reference bounds; audit asset geometry before training")
        self.bounds = torch.tensor(list(self.settings["body_bounds_m"].values()), device=self.device)
        self.wheel_bodies, found = self.robot.find_bodies(["left_wheel_link", "right_wheel_link"], preserve_order=True)
        if found != ["left_wheel_link", "right_wheel_link"]:
            raise ValueError("Wheel body mapping mismatch")
        self.physics = terms.physics_tensors(profile.physics, self.device)
        self.default_q = torch.tensor(self.settings["q_default_rad"], device=self.device)
        self.commands = torch.zeros((self.num_envs, 3), device=self.device)
        self.height_commands = torch.full((self.num_envs, 1), self.settings["height_command_m"], device=self.device)
        self.raw_action = torch.zeros((self.num_envs, 6), device=self.device)
        self.previous_action = torch.zeros_like(self.raw_action)
        self.applied_action = torch.zeros_like(self.raw_action)
        self.torque = torch.zeros((self.num_envs, 8), device=self.device)
        self.motor_effort = torch.zeros((self.num_envs, 4), device=self.device)
        self.motor_rate = torch.zeros_like(self.motor_effort)
        self.torque_saturated = torch.zeros((self.num_envs, 6), dtype=torch.bool, device=self.device)
        self.first = torch.ones(self.num_envs, dtype=torch.bool, device=self.device)
        self.roof_touched = torch.zeros_like(self.first)
        self.cleared_tunnel = torch.zeros_like(self.first)
        self.previous_min_x = torch.full((self.num_envs,), -torch.inf, device=self.device)
        self.success = torch.zeros_like(self.first)
        self.wheel_ground = torch.zeros((self.num_envs, 2), dtype=torch.bool, device=self.device)
        self.mode = torch.tensor(profile.physics.normal_mode, device=self.device).repeat(self.num_envs, 1)
        self.last_x = torch.zeros(self.num_envs, device=self.device)
        self.total_successes = 0

    def _setup_scene(self) -> None:
        self.robot = Articulation(self.robot_cfg)
        sim_utils.spawn_ground_plane("/World/ground", cfg=sim_utils.GroundPlaneCfg())
        if self.stage["tunnel"]:
            t = self.settings["tunnel_geometry"]
            self._box(
                "TunnelRoof",
                [t["length_m"], t["width_m"], t["roof_thickness_m"]],
                [0, 0, t["clearance_m"] + t["roof_thickness_m"] / 2],
                t["color"][:3],
            )
            for side in [-1, 1]:
                self._box(
                    "TunnelWallLeft" if side == 1 else "TunnelWallRight",
                    [t["length_m"], t["wall_thickness_m"], t["clearance_m"]],
                    [0, side * (t["width_m"] - t["wall_thickness_m"]) / 2, t["clearance_m"] / 2],
                    t["color"][:3],
                )
            angle = math.atan2(t["ramp_height_m"], t["ramp_length_m"])
            thickness = self.settings["ramp_thickness_m"]
            self._box(
                "LaunchRamp",
                [math.hypot(t["ramp_length_m"], t["ramp_height_m"]), t["width_m"], thickness],
                [
                    t["ramp_center_x_m"] + thickness / 2 * math.sin(angle),
                    0,
                    t["ramp_height_m"] / 2 - thickness / 2 * math.cos(angle),
                ],
                [0.85, 0.55, 0.15],
                orientation=[math.cos(angle / 2), 0, -math.sin(angle / 2), 0],
            )
        elif self.stage["tile"] == "rough":
            rng = np.random.default_rng(self.settings["rough_seed"])
            count, size = self.settings["rough_box_count"], self.settings["rough_patch_size_m"]
            for i in range(count):  # Geometry creation once, not per-environment simulation.
                for j in range(count):
                    h = float(rng.uniform(*self.settings["rough_height_range_m"]))
                    self._box(
                        f"Rough_{i}_{j}",
                        [size / count, size / count, h],
                        [(i + 0.5) * size / count - size / 2, (j + 0.5) * size / count - size / 2, h / 2],
                        [0.42, 0.52, 0.30],
                    )
        self.scene.clone_environments(copy_from_source=False)
        if self.device == "cpu":
            self.scene.filter_collisions(global_prim_paths=["/World/ground"])
        self.scene.articulations["robot"] = self.robot
        self.roof_sensors = []
        if self.stage["tunnel"]:
            # Filtered contact sensors use one robot body per sensor (Isaac Lab one-to-many restriction).
            for i, name in enumerate(self.bounds_names):
                sensor = ContactSensor(
                    ContactSensorCfg(
                        prim_path=f"/World/envs/env_.*/Robot/{name}",
                        filter_prim_paths_expr=["/World/envs/env_.*/TunnelRoof"],
                        history_length=1,
                    )
                )
                self.scene.sensors[f"roof_{i}"] = sensor
                self.roof_sensors.append(sensor)
        self.wheel_sensors = []
        for side in ["left", "right"]:
            sensor = ContactSensor(
                ContactSensorCfg(
                    prim_path=f"/World/envs/env_.*/Robot/{side}_wheel_link",
                    filter_prim_paths_expr=["/World/ground"],
                    history_length=1,
                )
            )
            self.scene.sensors[f"ground_{side}"] = sensor
            self.wheel_sensors.append(sensor)
        light = sim_utils.DomeLightCfg(
            intensity=self.settings["light_intensity"], color=tuple(self.settings["light_color"])
        )
        light.func("/World/Light", light)

    def _box(self, name: str, size: list, position: list, color: list, orientation: list = (1, 0, 0, 0)) -> None:
        cfg = sim_utils.CuboidCfg(
            size=tuple(size),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=tuple(color)),
        )
        cfg.func(f"/World/envs/env_0/{name}", cfg, translation=tuple(position), orientation=tuple(orientation))

    def _pre_physics_step(self, actions: torch.Tensor) -> None:
        if not torch.isfinite(actions).all():
            raise ValueError("Actor returned non-finite actions")
        self.torque_saturated.zero_()
        self.previous_action.copy_(self.raw_action)
        self.raw_action.copy_(actions)
        self.applied_action.copy_(actions.clamp(-self.profile.policy.action_clip, self.profile.policy.action_clip))
        self.last_x.copy_(self.robot.data.root_pos_w[:, 0])

    def _update_contacts(self) -> None:
        for sensor in self.roof_sensors:
            self.roof_touched |= sensor.data.force_matrix_w.flatten(1).abs().amax(dim=1) > 0
        for i, sensor in enumerate(self.wheel_sensors):
            self.wheel_ground[:, i] = sensor.data.force_matrix_w.flatten(1).abs().amax(dim=1) > 0

    def _apply_action(self) -> None:
        self._update_contacts()
        self.torque, self.motor_effort, self.motor_rate = terms.lowlevel(
            self.physics,
            self.robot.data.joint_pos[:, self.source_joints],
            self.robot.data.joint_vel[:, self.source_joints],
            self.applied_action[:, self.inverse],
            self.motor_effort,
            self.motor_rate,
            self.first,
            self.physics_dt,
        )
        if not torch.isfinite(self.torque).all():
            raise ValueError("Non-finite low-level torque")
        lower, upper = self.physics["effort_min"][:6], self.physics["effort_max"][:6]
        ratio = self.settings["torque_saturation_ratio"]
        self.torque_saturated |= (self.torque[:, :6] <= ratio * lower) | (self.torque[:, :6] >= ratio * upper)
        self.first[:] = False
        self.robot.set_joint_effort_target(self.torque, joint_ids=self.source_joints)

    def _get_observations(self) -> dict:
        q = self.robot.data.joint_pos[:, self.srm_joints] - self.default_q
        q[:, self.settings["wheel_indices"]] = 0
        return {
            "policy": terms.observation(
                self.profile.policy,
                self.commands,
                self.height_commands,
                self.robot.data.root_ang_vel_b,
                self.robot.data.projected_gravity_b,
                q,
                self.robot.data.joint_vel[:, self.srm_joints],
                self.raw_action,
                self.mode,
            )
        }

    def _get_dones(self) -> tuple[torch.Tensor, torch.Tensor]:
        self._update_contacts()
        pos = self.robot.data.root_pos_w - self.scene.env_origins
        failed = self.robot.data.projected_gravity_b[:, 2] > self.settings["terminate_gravity_z"]
        failed |= pos[:, 2] < self.settings["terminate_base_height_m"]
        extent = self.stage["half_extent_m"] if self.stage["tile"] == "flat" else self.settings["tile_half_extent_m"]
        self.boundary_failed = (pos[:, :2].abs() > extent).any(dim=1)
        self.height_failed = pos[:, 2] < self.settings["terminate_base_height_m"]
        self.tilt_failed = self.robot.data.projected_gravity_b[:, 2] > self.settings["terminate_gravity_z"]
        failed |= self.boundary_failed
        self.success[:] = False
        if self.stage["tunnel"]:
            positions = self.robot.data.body_pos_w[:, self.bound_bodies] - self.scene.env_origins[:, None]
            t = self.settings["tunnel_geometry"]
            self.cleared_tunnel |= terms.clear_roof(
                positions,
                self.bounds,
                self.previous_min_x,
                self.wheel_ground,
                t["length_m"] / 2,
                t["clearance_m"] + t["roof_thickness_m"],
                t["width_m"],
            )
            self.previous_min_x[:] = (positions[:, :, 0] - self.bounds).amin(dim=1)
            self.success[:] = terms.tunnel_success(
                positions,
                self.bounds,
                self.wheel_ground,
                self.roof_touched,
                self.settings["tunnel_landing_x_m"],
                self.settings["tunnel_landing_y_m"],
            )
            failed |= self.roof_touched
            self.success &= ~failed
            self.success &= self.cleared_tunnel
        # DirectRLEnv resets done environments before returning step observations.
        self.final_observation = self._get_observations()["policy"].clone()
        return failed | self.success, self.episode_length_buf >= self.max_episode_length - 1

    def _get_rewards(self) -> torch.Tensor:
        pos = self.robot.data.root_pos_w - self.scene.env_origins
        offset = terms.wheel_forward_offset(
            self.robot.data.body_pos_w[:, self.wheel_bodies], self.robot.data.root_quat_w
        )
        values = {
            "no_fork": terms.no_fork(
                offset, self.settings["no_fork_tolerance_m"], self.settings["no_fork_scale_per_m"]
            ),
            "alive": torch.ones(self.num_envs, device=self.device),
            "track_forward": terms.track_forward(
                self.robot.data.root_lin_vel_b, self.commands, self.settings["tracking_variance"]
            ),
            "track_yaw": terms.track_yaw(
                self.robot.data.root_ang_vel_b, self.commands, self.settings["tracking_variance"]
            ),
            "upright": terms.upright(self.robot.data.projected_gravity_b),
            "height": terms.height(pos[:, 2], self.height_commands[:, 0], self.settings["height_variance_m2"]),
            "vertical_velocity": terms.vertical_velocity(self.robot.data.root_lin_vel_w),
            "roll_pitch_velocity": terms.roll_pitch_velocity(self.robot.data.root_ang_vel_b),
            "effort": terms.effort(self.torque),
            "action_rate": terms.action_rate(
                self.applied_action,
                self.previous_action.clamp(-self.profile.policy.action_clip, self.profile.policy.action_clip),
            ),
        }
        weighted = {name: value * self.settings["rewards"][name] * self.step_dt for name, value in values.items()}
        failed = self.reset_terminated & ~self.success
        reward = sum(weighted.values()) + self.settings["rewards"]["termination"] * failed
        if self.stage["tunnel"]:
            reward += self.settings["rewards"]["tunnel_progress"] * (self.robot.data.root_pos_w[:, 0] - self.last_x)
            reward += self.settings["rewards"]["tunnel_success"] * self.success
        self.extras["log"] = {f"Reward/{name}": value.mean() for name, value in weighted.items()}
        self.extras["log"].update(
            {"Metrics/failure_fraction": failed.float().mean(), "Metrics/success_fraction": self.success.float().mean()}
        )
        self.extras["log"].update(
            terms.motion_diagnostics(
                self.robot.data.root_lin_vel_b,
                self.robot.data.root_ang_vel_b,
                self.commands,
                self.raw_action,
                self.profile.policy.action_clip,
            )
        )
        self.extras["log"].update(
            {
                "Metrics/wheel_fore_aft_gap_m": offset.abs().mean(),
                "Metrics/no_fork_exceed_fraction": (offset.abs() > self.settings["no_fork_tolerance_m"]).float().mean(),
                "Metrics/torque_saturation_fraction": self.torque_saturated.float().mean(),
                "Metrics/boundary_failure_fraction": self.boundary_failed.float().mean(),
                "Metrics/height_failure_fraction": self.height_failed.float().mean(),
                "Metrics/tilt_failure_fraction": self.tilt_failed.float().mean(),
            }
        )
        return reward

    def _reset_idx(self, env_ids: torch.Tensor | None) -> None:
        if env_ids is None:
            env_ids = self.robot._ALL_INDICES
        super()._reset_idx(env_ids)
        count = len(env_ids)
        root = self.robot.data.default_root_state[env_ids].clone()
        root[:, :3] += self.scene.env_origins[env_ids]
        root[:, 0] += self.stage["spawn_x_m"] if self.stage["tile"] == "flat" else self.settings["spawn_x_m"]
        yaw = sample_uniform(*self.settings["reset_yaw_range_rad"], (count,), self.device)
        root[:, 3:7] = quat_from_euler_xyz(torch.zeros_like(yaw), torch.zeros_like(yaw), yaw)
        self.robot.write_root_pose_to_sim(root[:, :7], env_ids)
        self.robot.write_root_velocity_to_sim(root[:, 7:], env_ids)
        self.robot.write_joint_state_to_sim(
            self.robot.data.default_joint_pos[env_ids], self.robot.data.default_joint_vel[env_ids], env_ids=env_ids
        )
        self.commands[env_ids] = 0
        self.commands[env_ids, 0] = sample_uniform(*self.settings["command_vx_range_m_s"], (count,), self.device)
        self.commands[env_ids, 2] = sample_uniform(*self.settings["command_yaw_range_rad_s"], (count,), self.device)
        standing = torch.rand(count, device=self.device) < self.settings["standing_fraction"]
        self.commands[env_ids[standing]] = 0
        if self.stage["tunnel"]:
            self.commands[env_ids] = torch.tensor([self.stage["forward_command_m_s"], 0, 0], device=self.device)
        self.raw_action[env_ids] = self.previous_action[env_ids] = self.applied_action[env_ids] = 0
        self.motor_effort[env_ids] = self.motor_rate[env_ids] = 0
        self.first[env_ids], self.roof_touched[env_ids], self.success[env_ids] = True, False, False
        self.cleared_tunnel[env_ids] = False
        self.previous_min_x[env_ids] = -torch.inf
