"""Simulator-independent SRM observation, reward and SCUT force calculations on Torch tensors."""

import torch

from .config import PolicyConfig
from .observation import OBS_FIELDS
from .scut_policy import ScutConfig


def observation(
    policy: PolicyConfig,
    command: torch.Tensor,
    height: torch.Tensor,
    angular_b: torch.Tensor,
    gravity_b: torch.Tensor,
    q_relative: torch.Tensor,
    dq: torch.Tensor,
    previous: torch.Tensor,
    mode: torch.Tensor,
) -> torch.Tensor:
    fields = {
        "command": command * torch.tensor(policy.command_scale, device=command.device),
        "height": height * policy.height_scale,
        "angular_velocity": angular_b * policy.angular_velocity_scale,
        "gravity": gravity_b * policy.gravity_scale,
        "joint_position": q_relative * policy.joint_position_scale,
        "joint_velocity": dq * policy.joint_velocity_scale,
        "previous_action": previous,
        "mode": mode,
    }
    return torch.cat([fields[name] for name, _ in OBS_FIELDS], dim=-1)


def physics_tensors(cfg: ScutConfig, device: str) -> dict:
    return {
        "parameters": {
            k: torch.tensor(v, dtype=torch.float32, device=device)
            for k, v in cfg.parameters.items()
            if isinstance(v, tuple)
        },
        "actuator": cfg.actuator,
        "spring": cfg.spring,
        "effort_min": torch.tensor(cfg.effort_min, device=device),
        "effort_max": torch.tensor(cfg.effort_max, device=device),
    }


def lowlevel(
    cfg: dict,
    q: torch.Tensor,
    dq: torch.Tensor,
    action: torch.Tensor,
    effort: torch.Tensor,
    rate: torch.Tensor,
    first: torch.Tensor,
    dt: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Torch equivalent of scut_lowlevel; SCUT joint order (N,8), action (N,6)."""
    p, a, s = cfg["parameters"], cfg["actuator"], cfg["spring"]
    target = action * p["joint_action_scale"][:6] + p["default_dof_pos"][:6]
    error = (target[:, :4] - q[:, :4] + torch.pi) % (2 * torch.pi) - torch.pi
    output = torch.zeros_like(q)
    output[:, :4] = p["joint_stiffness"][:4] * error - p["joint_damping"][:4] * dq[:, :4]
    output[:, 4:6] = p["joint_damping"][4:6] * (target[:, 4:6] - dq[:, 4:6])
    output += p["joint_bias"]
    output = torch.clamp(output, p["joint_output_min"], p["joint_output_max"])
    ratio = (q[:, 6:].clamp(s["q_min"], s["q_max"]) - s["q_min"]) / (s["q_max"] - s["q_min"])
    output[:, 6:] += (
        s["force_at_q_min"]
        + (s["force_at_q_max"] - s["force_at_q_min"]) * ratio
        - s["manual_viscous_damping"] * dq[:, 6:]
        - s["manual_static_friction"] * torch.tanh(dq[:, 6:] / s["manual_velocity_epsilon"])
    )
    output = torch.clamp(output, cfg["effort_min"], cfg["effort_max"])
    effort = torch.where(first[:, None], a["actuator_dc_gain"] * output[:, :4], effort)
    droop = (dq[:, :4].abs() - a["actuator_speed_droop_start_rad_s"]).clamp_min(0)
    gain = (1 - a["actuator_speed_droop_per_rad_s"] * droop).clamp(a["actuator_min_speed_gain"], 1)
    target_effort = a["actuator_dc_gain"] * gain * output[:, :4]
    wn = 2 * torch.pi * a["actuator_natural_frequency_hz"]
    rate = (rate + dt * (wn**2 * (target_effort - effort) - 2 * a["actuator_damping_ratio"] * wn * rate)).clamp(
        -a["actuator_torque_slew_rate_nm_s"], a["actuator_torque_slew_rate_nm_s"]
    )
    raw = effort + dt * rate
    effort = raw.clamp(-a["actuator_output_limit"], a["actuator_output_limit"])
    rate = torch.where((effort != raw) & (effort * rate > 0), 0, rate)
    output[:, :4] = effort
    return output, effort, rate


def track_forward(velocity_b: torch.Tensor, command: torch.Tensor, variance: float) -> torch.Tensor:
    return torch.exp(-(velocity_b[:, 0] - command[:, 0]).square() / variance)


def track_yaw(angular_b: torch.Tensor, command: torch.Tensor, variance: float) -> torch.Tensor:
    return torch.exp(-(angular_b[:, 2] - command[:, 2]).square() / variance)


def upright(gravity: torch.Tensor) -> torch.Tensor:
    return (-gravity[:, 2]).clamp(0, 1)


def height(base_z: torch.Tensor, target: torch.Tensor, variance: float) -> torch.Tensor:
    return torch.exp(-(base_z - target).square() / variance)


def vertical_velocity(velocity_w: torch.Tensor) -> torch.Tensor:
    return velocity_w[:, 2].square()


def roll_pitch_velocity(angular_b: torch.Tensor) -> torch.Tensor:
    return angular_b[:, :2].square().sum(dim=1)


def effort(torque: torch.Tensor) -> torch.Tensor:
    return torque[:, :6].square().sum(dim=1)


def action_rate(action: torch.Tensor, previous: torch.Tensor) -> torch.Tensor:
    return (action - previous).square().sum(dim=1)


def tunnel_success(
    body_positions: torch.Tensor,
    radii: torch.Tensor,
    wheel_ground: torch.Tensor,
    roof_touched: torch.Tensor,
    landing_x: tuple,
    landing_y: tuple,
) -> torch.Tensor:
    low, high = body_positions - radii[None, :, None], body_positions + radii[None, :, None]
    return (
        (low[:, :, 0].amin(dim=1) > landing_x[0])
        & (high[:, :, 0].amax(dim=1) < landing_x[1])
        & (low[:, :, 1].amin(dim=1) > landing_y[0])
        & (high[:, :, 1].amax(dim=1) < landing_y[1])
        & wheel_ground.all(dim=1)
        & ~roof_touched
    )


def clear_roof(
    body_positions: torch.Tensor,
    radii: torch.Tensor,
    previous_min_x: torch.Tensor,
    wheel_ground: torch.Tensor,
    roof_rear_x: float,
    roof_top_z: float,
    roof_width: float,
) -> torch.Tensor:
    low, high = body_positions - radii[None, :, None], body_positions + radii[None, :, None]
    min_x = low[:, :, 0].amin(dim=1)
    return (
        (previous_min_x <= roof_rear_x)
        & (min_x > roof_rear_x)
        & (low[:, :, 2].amin(dim=1) > roof_top_z)
        & (low[:, :, 1].amin(dim=1) > -roof_width / 2)
        & (high[:, :, 1].amax(dim=1) < roof_width / 2)
        & ~wheel_ground.any(dim=1)
    )


def bootstrap_timeout(
    rewards: torch.Tensor, terminal_values: torch.Tensor, timeout: torch.Tensor, gamma: float
) -> torch.Tensor:
    return rewards + gamma * terminal_values * timeout


def wheel_forward_offset(wheel_positions_w: torch.Tensor, root_quat_w: torch.Tensor) -> torch.Tensor:
    """Signed left-minus-right wheel center distance on body x; quaternion wxyz."""
    w, x, y, z = root_quat_w.unbind(-1)
    forward_w = torch.stack((1 - 2 * (y.square() + z.square()), 2 * (x * y + w * z), 2 * (x * z - w * y)), dim=-1)
    return ((wheel_positions_w[:, 0] - wheel_positions_w[:, 1]) * forward_w).sum(-1)


def no_fork(offset_m: torch.Tensor, tolerance_m: float, scale_per_m: float) -> torch.Tensor:
    return ((offset_m.abs() - tolerance_m).clamp_min(0) * scale_per_m).square()


def motion_diagnostics(
    velocity_b: torch.Tensor, angular_b: torch.Tensor, commands: torch.Tensor, raw_action: torch.Tensor, clip: float
) -> dict[str, torch.Tensor]:
    vx_error = velocity_b[:, 0] - commands[:, 0]
    yaw_error = angular_b[:, 2] - commands[:, 2]
    standing = (commands == 0).all(dim=-1)
    result = {
        "Metrics/vx_rmse_m_s": vx_error.square().mean().sqrt(),
        "Metrics/yaw_rmse_rad_s": yaw_error.square().mean().sqrt(),
        "Metrics/action_clip_fraction": (raw_action.abs() > clip).float().mean(),
    }
    for label, mask in (("standing", standing), ("moving", ~standing)):
        count = mask.sum()
        result[f"Metrics/{label}_sample_fraction"] = mask.float().mean()
        # Empty groups have zero count and zero numerator; expose the count alongside the error.
        result[f"Metrics/{label}_vx_rmse_m_s"] = ((vx_error.square() * mask).sum() / count.clamp_min(1)).sqrt()
        result[f"Metrics/{label}_yaw_rmse_rad_s"] = ((yaw_error.square() * mask).sum() / count.clamp_min(1)).sqrt()
    for i in range(raw_action.shape[1]):
        result[f"Metrics/action_clip_channel_{i}"] = (raw_action[:, i].abs() > clip).float().mean()
    return result
