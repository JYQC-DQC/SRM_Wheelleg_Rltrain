"""One vectorized term per log channel. Guide sections 6.1, 6.5, 6.6."""

import torch


def track_lin_vel(s, p):
    return torch.exp(-s["linear_error"].square() / p["linear_sigma"]) * s["tracking_mask"]


def lin_vel_error(s, p):
    return (0.25 * s["linear_error"]).square() * s["tracking_mask"]


def track_ang_vel(s, p):
    return torch.exp(-s["angular_error"].square() / p["angular_sigma"]) * s["tracking_mask"]


def ang_vel_error(s, p):
    return (0.5 * s["angular_error"]).square() * s["tracking_mask"]


def track_height(s, p):
    return torch.exp(-s["height_error"].square() / p["height_sigma"]) * s["height_mask"]


def height_error(s, p):
    return (10 * s["height_error"]).square() * s["height_mask"]


def flat_roll(s, p):
    return torch.exp(-s["gravity"][:, 1].square() / p["roll_sigma"])


def flat_pitch(s, p):
    return torch.exp(-s["gravity"][:, 0].square() / p["pitch_sigma"])


def roll_penalty(s, p):
    return ((2 * torch.exp(-s["velocity"][:, 0].square() / 3) + 2) * s["gravity"][:, 1]).square()


def pitch_penalty(s, p):
    return ((2 * torch.exp(-s["velocity"][:, 0].square() / 3) + 2) * s["gravity"][:, 0]).square()


def vertical_velocity(s, p):
    return s["velocity"][:, 2].square() * s["height_mask"]


def angular_xy(s, p):
    return s["angular_velocity"][:, :2].square().sum(-1)


def no_fork(s, p):
    dx = (s["wheel_position_b"][:, 0, 0] - s["wheel_position_b"][:, 1, 0]).abs()
    return (dx > p["fork_deadzone_m"]).float()


def no_fork_square(s, p):
    dx = (s["wheel_position_b"][:, 0, 0] - s["wheel_position_b"][:, 1, 0]).abs()
    return (p["fork_square_scale"] * (dx - p["fork_deadzone_m"]).clamp_min(0)).square()


def leg_symmetry(s, p):
    return (s["leg_angle"][:, 0] - s["leg_angle"][:, 1]).square() + p["leg_length_symmetry_scale"] * (
        s["leg_length"][:, 0] - s["leg_length"][:, 1]
    ).square()


def undesired_contact(s, p):
    return (s["undesired_force"] > p["contact_force_n"]).float().sum(-1) * s["contact_multiplier"]


def stand_still(s, p):
    return s["velocity"][:, :2].square().sum(-1) * (s["requested_speed"] < p["stand_deadzone"])


def joint_torque(s, p):
    return s["torque"].square().sum(-1)


def wheel_power(s, p):
    return (s["wheel_torque"] * s["wheel_velocity"]).abs().sum(-1)


def action_rate(s, p):
    return (s["action"] - s["previous_action"]).square().sum(-1)


def termination(s, p):
    return s["terminated"].float() * s["termination_multiplier"]


def spin_velocity(s, p):
    return torch.exp(-s["translation_error"].square().sum(-1) / p["spin_velocity_sigma"])


def spin_speed(s, p):
    return torch.exp(-s["speed_error"].square() / p["spin_velocity_sigma"])


def spin_heading(s, p):
    return torch.exp(-s["heading_error"].square() / p["spin_heading_sigma"]) * (
        s["requested_speed"] > p["stand_deadzone"]
    )


def spin_velocity_error(s, p):
    return s["translation_error"].square().sum(-1)


def spin_speed_error(s, p):
    return s["speed_error"].square()


def jump_apex(s, p):
    error = (s["jump"].height - (s["jump"].apex_z - s["jump"].start_z)).clamp_min(0)
    return torch.exp(-error.square() / s["jump"].settings["apex_sigma"]) * s["jump"].apex_pulse


def jump_landing(s, p):
    return s["jump"].landing_pulse.float()


def jump_flight(s, p):
    return s["jump_ref"]["flight"].float()


def jump_crouch(s, p):
    error = (s["leg_length"] - s["jump"].settings["crouch_leg_length_m"]).abs().sum(-1)
    return torch.exp(-4 * error) * s["jump_ref"]["crouch"] * s["guidance_scale"]


def jump_takeoff(s, p):
    target = s["jump_ref"]["takeoff_velocity"]
    ratio = s["velocity_w"][:, 2] / target.clamp_min(torch.finfo(target.dtype).eps)
    return ratio.clamp(0, 1) * s["jump_ref"]["push"] * s["guidance_scale"]


def jump_push_symmetry(s, p):
    force = s["wheel_force"].clamp_min(0)
    return (1 - (force[:, 0] - force[:, 1]).abs() / force.sum(-1).clamp_min(1)) * s["jump_ref"]["push"]


def jump_tuck(s, p):
    error = (s["leg_length"] - s["jump"].settings["tuck_leg_length_m"]).abs().sum(-1)
    return torch.exp(-4 * error) * s["jump_ref"]["tuck"] * s["guidance_scale"]


def jump_prepare(s, p):
    error = (s["leg_length"] - s["jump"].settings["landing_leg_length_m"]).abs().sum(-1)
    return torch.exp(-4 * error) * s["jump_ref"]["prepare"] * s["guidance_scale"]


def jump_impact(s, p):
    return (s["hip_torque"].square().amax(-1) + s["hip_velocity"].square().sum(-1)) * s["jump"].touchdown_pulse


def jump_asymmetric_landing(s, p):
    times = s["jump"].touchdown_time
    return ((times[:, 0] - times[:, 1]).abs() > s["jump"].settings["max_touchdown_difference_s"]).float() * s[
        "jump"
    ].touchdown_pulse


def uncommanded_flight(s, p):
    return (s["airborne"] & ~s["jump"].active & ~s["jump"].landing_pulse).float()


TERMS = {
    f.__name__: f
    for f in (
        track_lin_vel,
        lin_vel_error,
        track_ang_vel,
        ang_vel_error,
        track_height,
        height_error,
        flat_roll,
        flat_pitch,
        roll_penalty,
        pitch_penalty,
        vertical_velocity,
        angular_xy,
        no_fork,
        no_fork_square,
        undesired_contact,
        stand_still,
        joint_torque,
        wheel_power,
        action_rate,
        termination,
        spin_velocity,
        spin_speed,
        spin_heading,
        spin_velocity_error,
        spin_speed_error,
        leg_symmetry,
        jump_apex,
        jump_landing,
        jump_flight,
        jump_crouch,
        jump_takeoff,
        jump_push_symmetry,
        jump_tuck,
        jump_prepare,
        jump_impact,
        jump_asymmetric_landing,
        uncommanded_flight,
    )
}


EVENT_TERMS = frozenset(
    (
        "termination",
        "jump_apex",
        "jump_landing",
        "jump_impact",
        "jump_asymmetric_landing",
        "tunnel_crossing",
    )
)


def compute_rewards(state: dict, parameters: dict, weights: dict, dt: float, clip: float) -> dict[str, torch.Tensor]:
    # Event weights are total payouts: neither dt nor the continuous-term clip applies.
    return {
        name: TERMS[name](state, parameters) * weight
        if name in EVENT_TERMS
        else (TERMS[name](state, parameters) * weight * dt).clamp(-clip, clip)
        for name, weight in weights.items()
        if weight != 0
    }
