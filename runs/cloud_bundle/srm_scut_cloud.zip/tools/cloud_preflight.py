"""Inspect the cloud image and upload contents without launching Isaac Sim or PPO."""

import argparse
import importlib.metadata
import importlib.util
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/policies/srm_scut/policy_meta.yaml"))
    parser.add_argument("--output", type=Path, default=Path("runs/cloud_preflight.json"))
    args = parser.parse_args()
    import yaml

    cfg = yaml.safe_load(args.config.read_text("utf-8"))["training"]
    errors, versions = [], {}
    for name in ["isaaclab", "isaacsim", "torch", "rsl-rl-lib", "mujoco", "onnxruntime", "tensorboard"]:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
            errors.append(f"Missing distribution: {name}")
    for module in ["git", "gymnasium", "onnx", "glfw", "etils", "matplotlib", "isaaclab.app"]:
        try:
            present = importlib.util.find_spec(module) is not None
        except ModuleNotFoundError:
            present = False
        if not present:
            errors.append(f"Missing import: {module}; install only the missing dependency, without upgrading Torch")
    if versions["isaaclab"] != "2.3.2":
        errors.append("Expected Isaac Lab 2.3.2")
    if versions["isaacsim"] is not None and not versions["isaacsim"].startswith("5.1"):
        errors.append("Expected Isaac Sim 5.1.x")
    if versions["rsl-rl-lib"] != "2.3.1":
        errors.append("Activate the RSL-RL 2.3.1 overlay")
    gpu = None
    if versions["torch"] is not None:
        import torch

        if torch.cuda.is_available():
            gpu = {
                "name": torch.cuda.get_device_name(),
                "cuda": torch.version.cuda,
                "memory_bytes": torch.cuda.get_device_properties(0).total_memory,
            }
        else:
            errors.append("CUDA is unavailable; do not start the cloud trainer")
    asset_root = (args.config.parent / cfg["reference_assets"]).resolve()
    usd = asset_root / "agent_world/assets/usd_files/wheelbipeV14_2_1/wheelbipeV14_2.usd"
    if not usd.is_file():
        errors.append(f"Missing reference asset: {usd}")
    for key in ["scene", "scut_parameters"]:
        if not (args.config.parent / cfg[key]).is_file():
            errors.append(f"Missing profile input: {cfg[key]}")
    report = {
        "versions": versions,
        "gpu": gpu,
        "errors": errors,
        "ready_for_environment_probe": not errors,
        "ppo_training_executed": False,
        "note": "Metadata preflight is not a physics or training validation",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
