"""Play a cloud-trained SRM-order actor on the SCUT MuJoCo reference robot, without training."""

import argparse
import hashlib
import json
import time
from contextlib import nullcontext
from pathlib import Path

import mujoco
import torch

from wheelleg.actor import build_actor
from wheelleg.mujoco_train import MujocoTrainEnv, load_training_profile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True, type=Path, help="Cloud output actor_state.pt")
    parser.add_argument("--config", type=Path, default=Path("config/policies/srm_scut/policy_meta.yaml"))
    parser.add_argument("--stage", choices=["flat", "rough", "tunnel"], default="flat")
    parser.add_argument("--duration", type=float, default=10)
    parser.add_argument("--vx", type=float, default=0)
    parser.add_argument("--yaw", type=float, default=0)
    parser.add_argument("--headless", action="store_true")
    args = parser.parse_args()
    if args.duration <= 0:
        parser.error("duration must be positive")
    profile = load_training_profile(args.config)
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    if (
        saved["contract"] != "srm_scut_obs_v2"
        or saved["obs_version"] != 2
        or saved["profile_sha256"] != hashlib.sha256(args.config.read_bytes()).hexdigest()
    ):
        raise ValueError("Checkpoint contract/profile differs; copy the matching cloud training profile")
    actor = build_actor(profile.policy).eval()
    actor.load_state_dict(saved["actor_state_dict"], strict=True)
    env = MujocoTrainEnv(profile, stage=args.stage, num_envs=1)
    data = mujoco.MjData(env.model)
    if args.headless:
        context = nullcontext(None)
    else:
        from mujoco import viewer as mj_viewer

        context = mj_viewer.launch_passive(env.model, data)
    steps = 0
    try:
        with context as viewer:
            if viewer is not None:
                viewer.cam.distance = 3
            while steps * env.step_dt < args.duration and (viewer is None or viewer.is_running()):
                start = time.perf_counter()
                env.command[:] = [args.vx, 0, args.yaw]
                obs, _ = env.get_observations()
                with torch.inference_mode():
                    env.step(actor(obs))
                steps += 1
                if viewer is not None:
                    with viewer.lock():
                        mujoco.mj_setState(env.model, data, env.state[0], mujoco.mjtState.mjSTATE_FULLPHYSICS)
                        mujoco.mj_forward(env.model, data)
                        viewer.cam.lookat[:] = data.qpos[:3]
                    viewer.sync()
                    time.sleep(max(0, env.step_dt - (time.perf_counter() - start)))
        print(
            json.dumps(
                {
                    "simulated_seconds": steps * env.step_dt,
                    "failures": env.total_failures,
                    "tunnel_successes": env.total_successes,
                    "physics_faults": env.total_physics_faults,
                    "scope": "Inference only. Isaac-trained policy success in MuJoCo is not guaranteed.",
                }
            )
        )
    finally:
        env.close()


if __name__ == "__main__":
    main()
