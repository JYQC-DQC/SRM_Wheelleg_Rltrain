"""Build an independent SCUT experience scene; never change the reference repositories."""

import argparse
import hashlib
import json
import shutil
import struct
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import yaml


def numbers(values: list | tuple | np.ndarray) -> str:
    return " ".join(f"{v:.9g}" for v in values)


def box(world: ET.Element, name: str, pos: list, size: list, color: list, friction: list) -> None:
    ET.SubElement(
        world,
        "geom",
        name=name,
        type="box",
        pos=numbers(pos),
        size=numbers(size),
        rgba=numbers(color),
        friction=numbers(friction),
    )


def heightfield(tile: dict, cfg: dict, rng: np.random.Generator) -> np.ndarray:
    """Heights in metres; rows are y, columns are x. Basin is raised above a continuous floor."""
    half = cfg["tile_size_m"] / 2 - cfg["border_m"]
    n = round(2 * half / cfg["horizontal_scale_m"]) + 1
    axis = np.linspace(-half, half, n)
    x, y = np.meshgrid(axis, axis)
    radius = np.maximum(np.abs(x), np.abs(y))
    if tile["kind"] == "slope":
        return (half - radius) * tile["slope"]
    if tile["kind"] == "basin":
        return radius * tile["slope"]
    coarse_n = round(2 * half / tile["sample_scale_m"]) + 1
    coarse_axis = np.linspace(-half, half, coarse_n)
    levels = round(tile["max_height_m"] / tile["height_step_m"])
    coarse = rng.integers(0, levels + 1, (coarse_n, coarse_n)) * tile["height_step_m"]
    rows = np.array([np.interp(axis, coarse_axis, row) for row in coarse])
    result = np.array([np.interp(axis, coarse_axis, col) for col in rows.T]).T
    # Flat border joins the floor rather than leaving a vertical lip around rough ground.
    result[[0, -1], :] = 0
    result[:, [0, -1]] = 0
    return result


def add_terrain(root: ET.Element, tile: dict, cfg: dict, center: list, output: Path, rng: np.random.Generator) -> dict:
    world, asset = root.find("worldbody"), root.find("asset")
    name, kind = tile["name"], tile["kind"]
    cx, cy = center
    half = cfg["tile_size_m"] / 2 - cfg["border_m"]
    color, friction = tile["color"], cfg["friction"]
    meta = {
        "name": name,
        "kind": kind,
        "center_xy_m": center,
        "spawn_xy_m": [cx + cfg["spawn_offset_m"][0], cy + cfg["spawn_offset_m"][1]],
    }
    if kind in {"slope", "basin", "rough"}:
        heights = heightfield(tile, cfg, rng)
        path = output / f"{name}.hfield"
        path.write_bytes(struct.pack("<ii", *heights.shape) + heights.astype("<f4").tobytes())
        ET.SubElement(
            asset,
            "hfield",
            name=name,
            file=path.name,
            size=numbers([half, half, float(heights.max()), cfg["floor_thickness_m"]]),
        )
        ET.SubElement(
            world,
            "geom",
            name=f"terrain_{name}",
            type="hfield",
            hfield=name,
            pos=numbers([cx, cy, 0]),
            rgba=numbers(color),
            friction=numbers(friction),
        )
    elif kind in {"stairs", "inverse_stairs"}:
        count = int((half - tile["platform_width_m"] / 2) / tile["step_width_m"])
        for i in range(count):
            inner = half - (i + 1) * tile["step_width_m"]
            if kind == "stairs":
                height = (i + 1) * tile["step_height_m"]
                box(world, f"{name}_{i}", [cx, cy, height / 2], [inner, inner, height / 2], color, friction)
            else:
                # Disjoint square rings give actual vertical risers, unlike a sampled staircase hfield.
                outer = inner + tile["step_width_m"]
                height = (count - i) * tile["step_height_m"]
                width, mid = (outer - inner) / 2, (outer + inner) / 2
                for j, (dx, dy, sx, sy) in enumerate(
                    [
                        (-mid, 0, width, outer),
                        (mid, 0, width, outer),
                        (0, -mid, inner, width),
                        (0, mid, inner, width),
                    ]
                ):
                    box(world, f"{name}_{i}_{j}", [cx + dx, cy + dy, height / 2], [sx, sy, height / 2], color, friction)
    elif kind == "grid":
        centers = np.linspace(-half / 2, half / 2, tile["bars_per_axis"])
        h, w = tile["bar_height_m"], tile["bar_width_m"]
        for i, offset in enumerate(centers):
            box(world, f"{name}_x_{i}", [cx, cy + offset, h / 2], [half, w / 2, h / 2], color, friction)
            box(world, f"{name}_y_{i}", [cx + offset, cy, h / 2], [w / 2, half, h / 2], color, friction)
    elif kind == "tunnel":
        length, width, wall = tile["length_m"], tile["width_m"], tile["wall_thickness_m"]
        roof, clearance = tile["roof_thickness_m"], tile["clearance_m"]
        box(world, "tunnel_roof", [cx, cy, clearance + roof / 2], [length / 2, width / 2, roof / 2], color, friction)
        for side in [-1, 1]:
            box(
                world,
                f"tunnel_wall_{side}",
                [cx, cy + side * (width - wall) / 2, clearance / 2],
                [length / 2, wall / 2, clearance / 2],
                color,
                friction,
            )
        ramp_x, ramp_l, ramp_h = tile["ramp_center_x_m"], tile["ramp_length_m"], tile["ramp_height_m"]
        vertices = [
            [x, y, z]
            for y in [-width / 2, width / 2]
            for x, z in [(-ramp_l / 2, 0), (ramp_l / 2, 0), (ramp_l / 2, ramp_h)]
        ]
        ET.SubElement(asset, "mesh", name="launch_wedge", vertex=numbers(np.array(vertices).ravel()))
        ET.SubElement(
            world,
            "geom",
            name="launch_ramp",
            type="mesh",
            mesh="launch_wedge",
            pos=numbers([cx + ramp_x, cy, 0]),
            rgba="0.85 0.55 0.15 1",
            friction=numbers(friction),
        )
        landing = [cx + tile["landing_start_x_m"], cx + tile["landing_start_x_m"] + tile["landing_length_m"]]
        ET.SubElement(
            world,
            "site",
            name="landing_target",
            type="box",
            pos=numbers([sum(landing) / 2, cy, 0.004]),
            size=numbers([tile["landing_length_m"] / 2, width / 2, 0.004]),
            rgba="0.2 0.9 0.4 0.5",
        )
        meta.update(
            {
                "forbidden_landing_geom": "tunnel_roof",
                "landing_x_range_m": landing,
                "landing_y_range_m": [cy - width / 2, cy + width / 2],
                "landing_rule": "Entire robot must pass the rear edge and land on ground; roof contact is not success.",
            }
        )
    return meta


def build_scene(config_path: Path, reference: Path, output: Path) -> Path:
    cfg = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    for key in ["tile_size_m", "border_m", "horizontal_scale_m", "physics_timestep_s", "floor_thickness_m"]:
        if not np.isfinite(cfg[key]) or cfg[key] <= 0:
            raise ValueError(f"{config_path}: {key} must be finite and positive")
    if cfg["tile_size_m"] <= 2 * cfg["border_m"] or cfg["columns"] < 1:
        raise ValueError(f"{config_path}: invalid tile border or column count")
    kinds = {"flat", "slope", "basin", "stairs", "inverse_stairs", "grid", "rough", "tunnel"}
    names = [t["name"] for t in cfg["tiles"]]
    if not names or len(set(names)) != len(names) or any(t["kind"] not in kinds for t in cfg["tiles"]):
        raise ValueError(f"{config_path}: tiles must have unique names and supported kinds")
    for tile in cfg["tiles"]:
        for key, value in tile.items():
            if key.endswith("_m") or key in {"slope", "bars_per_axis"}:
                if not np.isfinite(value) or value <= 0:
                    # The approach ramp is deliberately before the tunnel, in the negative x direction.
                    if key != "ramp_center_x_m" or not np.isfinite(value):
                        raise ValueError(f"{config_path}: {tile['name']}.{key} must be finite and positive")
        if tile["kind"] in {"stairs", "inverse_stairs"}:
            if tile["platform_width_m"] >= cfg["tile_size_m"] - 2 * cfg["border_m"]:
                raise ValueError(f"{config_path}: {tile['name']}.platform_width_m leaves no room for stairs")
    robot_path = reference / "src/resources/robot_descriptions/wheelbipeV14_2/mjcf/wheelbipeV14_2.xml"
    root = ET.parse(robot_path).getroot()
    output.mkdir(parents=True, exist_ok=True)
    mesh_dir = output / "robot/meshes"
    mesh_dir.mkdir(parents=True, exist_ok=True)
    for mesh in root.findall("asset/mesh"):
        original = (robot_path.parent / mesh.attrib["file"]).resolve()
        shutil.copy2(original, mesh_dir / original.name)
        mesh.set("file", f"robot/meshes/{original.name}")
    for source, destination in [
        (reference / "LICENSE", output / "SCUT_LICENSE.txt"),
        (reference / "THIRD_PARTY_NOTICES.md", output / "SCUT_THIRD_PARTY_NOTICES.md"),
        (robot_path.parent.parent / "meshes/ASSET_LICENSE.md", mesh_dir / "ASSET_LICENSE.md"),
    ]:
        shutil.copy2(source, destination)
    root.set("model", "scut_experience_course")
    ET.SubElement(root, "option", timestep=str(cfg["physics_timestep_s"]), integrator="implicitfast")
    rows = (len(cfg["tiles"]) + cfg["columns"] - 1) // cfg["columns"]
    center = [(cfg["columns"] - 1) * cfg["tile_size_m"] / 2, (rows - 1) * cfg["tile_size_m"] / 2, 0]
    ET.SubElement(
        root, "statistic", center=numbers(center), extent=str(max(rows, cfg["columns"]) * cfg["tile_size_m"] / 2)
    )
    visual = ET.SubElement(root, "visual")
    ET.SubElement(visual, "global", azimuth="125", elevation="-55", offwidth="1600", offheight="1000")
    asset, world = root.find("asset"), root.find("worldbody")
    ET.SubElement(
        asset,
        "texture",
        name="course_checker",
        type="2d",
        builtin="checker",
        width="128",
        height="128",
        rgb1="0.13 0.17 0.21",
        rgb2="0.20 0.24 0.28",
    )
    ET.SubElement(asset, "material", name="course_ground", texture="course_checker", texrepeat="1 1", texuniform="true")
    ET.SubElement(world, "light", pos="13.5 4.5 15", dir="0 0 -1", directional="true", diffuse="0.8 0.8 0.8")
    ET.SubElement(
        world,
        "geom",
        name="ground",
        type="plane",
        size="0 0 .1",
        material="course_ground",
        friction=numbers(cfg["friction"]),
    )
    rng = np.random.default_rng(cfg["seed"])
    tiles = []
    for i, tile in enumerate(cfg["tiles"]):
        center = [(i % cfg["columns"]) * cfg["tile_size_m"], (i // cfg["columns"]) * cfg["tile_size_m"]]
        tiles.append(add_terrain(root, tile, cfg, center, output, rng))
        ET.SubElement(
            world,
            "site",
            name=f"spawn_{tile['name']}",
            type="sphere",
            pos=numbers([*tiles[-1]["spawn_xy_m"], 0.02]),
            size="0.06",
            rgba="0.1 0.9 0.9 1",
        )
        # Non-colliding borders make each 9 m patch legible in the viewer.
        for side in [-1, 1]:
            ET.SubElement(
                world,
                "site",
                name=f"border_{i}_{side}",
                type="box",
                pos=numbers([center[0], center[1] + side * cfg["tile_size_m"] / 2, 0.005]),
                size=numbers([cfg["tile_size_m"] / 2, 0.015, 0.005]),
                rgba=numbers(tile["color"]),
            )
    base = world.find("body[@name='base_link']")
    original_position = np.fromstring(base.attrib["pos"], sep=" ")
    original_position[:2] = tiles[0]["spawn_xy_m"]
    base.set("pos", numbers(original_position))
    path = output / "scene.xml"
    ET.indent(root)
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
    shutil.copy2(config_path, output / "scene_config.yaml")
    (output / "terrain_manifest.json").write_text(
        json.dumps(
            {
                "purpose": "SCUT robot experience scene, not the measured SRM robot or an exact Isaac scene conversion",
                "robot_source": str(robot_path),
                "robot_sha256": hashlib.sha256(robot_path.read_bytes()).hexdigest(),
                "physics_timestep_s": cfg["physics_timestep_s"],
                "policy_controller_included": False,
                "training_environment_included": False,
                "tiles": tiles,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, required=True, help="SCUT wheelbipe_ros2_sim2sim repository")
    parser.add_argument("--config", type=Path, default=Path("config/scenes/scut_experience.yaml"))
    parser.add_argument("--output", type=Path, default=Path("runs/scut_experience"))
    args = parser.parse_args()
    path = build_scene(args.config, args.reference, args.output)
    print(path.resolve())


if __name__ == "__main__":
    main()
