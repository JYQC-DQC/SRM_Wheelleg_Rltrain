"""Import the SCUT normal-only ONNX and original parameter values without changing upstream."""

import argparse
import hashlib
import os
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml


def import_policy(reference: Path, output: Path, config: Path) -> None:
    controller = reference / "src/controllers/template_ros2_controller"
    definitions = yaml.safe_load((controller / "config/template_ros2_controller_parameters.yaml").read_text("utf-8"))
    parameters = {name: value["default_value"] for name, value in definitions["template_ros2_controller"].items()}
    if parameters["lowlevel_output_mode"] != "hardware_pd_vel" or parameters["rl_action_filter_type"] != "none":
        raise ValueError("Only upstream hardware_pd_vel with no action filter is supported")
    if parameters["enable_noise"] or parameters["enable_delay"]:
        raise ValueError("This player requires the upstream noise/delay defaults to be disabled")
    model = controller / parameters["rl_model_path"]
    root = ET.parse(reference / "src/resources/robot_descriptions/wheelbipe_V14/xacro/ros2control.xacro").getroot()
    properties = {
        p.attrib["name"].removeprefix("v14_"): float(p.attrib["value"])
        for p in root.findall("{http://www.ros.org/wiki/xacro}property")
        if p.attrib["value"] not in {"true", "false"}
    }
    spring = {}
    for p in root.findall(".//hardware/{http://www.ros.org/wiki/xacro}if/param"):
        if p.attrib["name"].startswith("gas_spring_"):
            spring[p.attrib["name"].removeprefix("gas_spring_")] = (
                p.text == "true" if p.text in {"true", "false"} else float(p.text)
            )
    joints, minimum, maximum = [], [], []
    for joint in root.findall(".//ros2_control/joint"):
        joints.append(joint.attrib["name"])
        effort = joint.find("command_interface[@name='effort']")
        minimum.append(float(effort.find("param[@name='min']").text))
        maximum.append(float(effort.find("param[@name='max']").text))
    keyboard = yaml.safe_load(
        (reference / "src/tools/keyboard_teleop/config/keyboard_teleop_params.yaml").read_text("utf-8")
    )
    keyboard = keyboard["/**"]["ros__parameters"]
    output.mkdir(parents=True, exist_ok=True)
    shutil.copy2(model, output / "policy.onnx")
    shutil.copy2(reference / "LICENSE", output / "SCUT_LICENSE.txt")
    shutil.copy2(controller / "policy/ASSET_LICENSE.md", output / "ASSET_LICENSE.md")
    shutil.copy2(reference / "THIRD_PARTY_NOTICES.md", output / "THIRD_PARTY_NOTICES.md")
    config.parent.mkdir(parents=True, exist_ok=True)
    # Model paths in imported config are relative to that config file, not the shell's cwd.
    payload = {
        "source_repository": "https://github.com/scutrobotlab/wheelbipe_ros2_sim2sim",
        "source_model": str(model.resolve()),
        "model": Path(os.path.relpath(output / "policy.onnx", config.parent)).as_posix(),
        "sha256": hashlib.sha256(model.read_bytes()).hexdigest(),
        "robot": "SCUT WheelBipe V14_2; not the SRM robot",
        "joint_names": joints,
        "parameters": parameters,
        "actuator": properties,
        "spring": spring,
        "hardware_effort_min": minimum,
        "hardware_effort_max": maximum,
        "keyboard": {key: keyboard[key] for key in ["lin_vel_x_step", "ang_vel_z_step", "height_step"]},
        "normal_mode": [1, 0, 0, 0, 0, 0, 0],
    }
    config.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print(f"Imported policy and {parameters['rl_inference_frequency']} Hz source parameters: {config.resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=Path("runs/scut_experience/policy"))
    parser.add_argument("--config", type=Path, default=Path("config/policies/scut_experience/policy_meta.yaml"))
    args = parser.parse_args()
    import_policy(args.reference, args.output, args.config)


if __name__ == "__main__":
    main()
