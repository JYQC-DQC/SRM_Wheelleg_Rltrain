"""Create a self-contained upload ZIP, including unchanged SCUT USD assets and MuJoCo comparison assets."""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, type=Path, help="SCUT wheeled-legged_RL training repository")
    parser.add_argument("--output", type=Path, default=Path("runs/cloud_bundle/srm_scut_cloud.zip"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    source = args.reference / "source/agent_world"
    usd = source / "agent_world/assets/usd_files/wheelbipeV14_2_1/wheelbipeV14_2.usd"
    if not usd.is_file():
        raise FileNotFoundError(usd)
    files = []
    for folder in ["wheelleg", "tools", "isaac", "cloud", "config", "docs", "tests"]:
        files += [
            (p, p.relative_to(root).as_posix())
            for p in (root / folder).rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
        ]
    for name in ["README.md", "LICENSE", "pyproject.toml", "AGENTS.md"]:
        files.append((root / name, name))
    files += [
        (p, "reference/agent_world/" + p.relative_to(source).as_posix())
        for p in source.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
    ]
    for name in ["LICENSE", "THIRD_PARTY_NOTICES.md"]:
        files.append((args.reference / name, "reference/SCUT_" + name))
    scene = root / "runs/scut_experience"
    files += [
        (p, p.relative_to(root).as_posix())
        for p in scene.rglob("*")
        if p.is_file()
        and p.suffix.lower() in {".xml", ".hfield", ".stl", ".md", ".txt", ".json", ".yaml"}
        and "policy" not in p.relative_to(scene).parts
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    hashes = {}
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, name in sorted(files, key=lambda item: item[1]):
            data = path.read_bytes()
            if path.suffix == ".sh":
                data = data.replace(b"\r\n", b"\n")
            hashes[name] = hashlib.sha256(data).hexdigest()
            archive.writestr(name, data)
        archive.writestr(
            "bundle_manifest.json",
            json.dumps(
                {
                    "purpose": "Cloud-only SRM-from-scratch PPO training on the SCUT reference robot",
                    "reference_training_repository": "https://github.com/scutrobotlab/wheeled-legged_RL",
                    "local_training_executed": False,
                    "teacher_weights_included": False,
                    "files_sha256": hashes,
                },
                indent=2,
            ),
        )
    print(json.dumps({"file": str(args.output.resolve()), "files": len(hashes), "bytes": args.output.stat().st_size}))


if __name__ == "__main__":
    main()
