"""Run the original SCUT normal-only ONNX in the custom MuJoCo experience scene."""

import argparse
import csv
import json
import math
import time
from contextlib import nullcontext
from datetime import datetime
from pathlib import Path
from queue import SimpleQueue

import mujoco
import numpy as np

from wheelleg.scut_policy import ScutController, load_scut_config


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/policies/scut_experience/policy_meta.yaml"))
    parser.add_argument("--scene", type=Path, default=Path("runs/scut_experience/scene.xml"))
    parser.add_argument("--tile", default="flat", help="Tile name in terrain_manifest.json")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument(
        "--duration", type=float, default=0, help="Simulation seconds; 0 = continuous GUI or 10 s headless"
    )
    parser.add_argument("--vx", type=float, default=0, help="Body-forward command, m/s")
    parser.add_argument("--yaw", type=float, default=0, help="Yaw-rate command, rad/s")
    parser.add_argument(
        "--height", type=float, default=None, help="Height command, m; defaults to original policy setting"
    )
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    cfg = load_scut_config(args.config)
    p = cfg.parameters
    command = np.array([args.vx, 0, args.yaw, p["default_command_height"] if args.height is None else args.height])
    lo = np.array([p["motion_linear_x_min"], 0, p["motion_angular_z_min"], p["command_height_min"]])
    hi = np.array([p["motion_linear_x_max"], 0, p["motion_angular_z_max"], p["command_height_max"]])
    if not np.isfinite(command).all() or np.any(command < lo) or np.any(command > hi):
        parser.error(f"command outside source limits {lo.tolist()} .. {hi.tolist()}")
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error("duration must be finite and nonnegative")
    duration = args.duration or (10 if args.headless else math.inf)
    model = mujoco.MjModel.from_xml_path(str(args.scene))
    data = mujoco.MjData(model)
    controller = ScutController(model, cfg)
    manifest = json.loads((args.scene.parent / "terrain_manifest.json").read_text("utf-8"))
    tiles = {t["name"]: t for t in manifest["tiles"]}
    if args.tile not in tiles:
        parser.error(f"tile must be one of {list(tiles)}")
    base = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "floating_base")
    if base < 0:
        raise ValueError("SCUT floating_base is missing")
    base_adr = model.jnt_qposadr[base]

    def reset() -> None:
        mujoco.mj_resetData(model, data)
        data.qpos[base_adr : base_adr + 2] = tiles[args.tile]["spawn_xy_m"]
        controller.reset()
        mujoco.mj_forward(model, data)

    reset()
    output = args.output or Path("runs/scut_play") / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output.mkdir(parents=True, exist_ok=True)
    (output / "policy_config.yaml").write_bytes(args.config.read_bytes())
    keys = SimpleQueue()
    if args.headless:
        context = nullcontext(None)
    else:
        from mujoco import viewer as mj_viewer

        context = mj_viewer.launch_passive(model, data, key_callback=keys.put)
    print(f"SCUT ONNX CPU | physics {p['update_rate']} Hz | policy {p['rl_inference_frequency']} Hz | tile {args.tile}")
    print("W/S forward, A/D yaw, T/G height, SPACE stop, R reset, P pause; no jump mode in this policy")
    print(f"Logs: {output.resolve()}")
    paused = False
    calls, steps, resets = 0, 0, 0
    worst_gravity_z = -1.0
    min_height_after_1s = math.inf
    failure = None
    with (output / "trace.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["episode_time_s", "x_m", "y_m", "z_m", "gravity_z", "vx_cmd", "yaw_cmd", "height_cmd"]
            + [f"obs_{i}" for i in range(35)]
            + [f"action_{i}" for i in range(6)]
        )
        with context as viewer:
            if viewer is not None:
                viewer.cam.lookat[:] = [*tiles[args.tile]["spawn_xy_m"], data.qpos[base_adr + 2]]
                viewer.cam.distance = 3
                viewer.cam.azimuth = 135
                viewer.cam.elevation = -20
            next_frame = time.perf_counter()
            next_draw = next_frame
            try:
                while steps * model.opt.timestep < duration and (viewer is None or viewer.is_running()):
                    while not keys.empty():
                        key = keys.get()
                        if key in [ord("W"), ord("S")]:
                            command[0] += cfg.keyboard["lin_vel_x_step"] * (1 if key == ord("W") else -1)
                        elif key in [ord("A"), ord("D")]:
                            command[2] += cfg.keyboard["ang_vel_z_step"] * (1 if key == ord("A") else -1)
                        elif key in [ord("T"), ord("G")]:
                            command[3] += cfg.keyboard["height_step"] * (1 if key == ord("T") else -1)
                        elif key == 32:
                            command[[0, 2]] = 0
                        elif key == ord("P"):
                            paused = not paused
                        elif key == ord("R"):
                            reset()
                            command[:] = [0, 0, 0, p["default_command_height"]]
                            resets += 1
                        command[:] = np.clip(command, lo, hi)
                    if not paused:
                        inferred = controller.step(data, command)
                        if inferred:
                            calls += 1
                            g_z = controller.observation[0, 9]
                            worst_gravity_z = max(worst_gravity_z, float(g_z))
                            xyz = data.qpos[base_adr : base_adr + 3]
                            if data.time >= 1:
                                min_height_after_1s = min(min_height_after_1s, float(xyz[2]))
                            writer.writerow(
                                [data.time, *xyz, g_z, command[0], command[2], command[3]]
                                + controller.observation[0].tolist()
                                + controller.action.tolist()
                            )
                        mujoco.mj_step(model, data)
                        steps += 1
                        if not np.isfinite(data.qpos).all() or not np.isfinite(data.qvel).all():
                            raise ValueError("MuJoCo state became non-finite")
                        if data.warning.number.any():
                            raise ValueError(f"MuJoCo reported warnings: {data.warning.number.tolist()}")
                    if viewer is not None:
                        # Keep camera tracking without preventing mouse changes to distance/azimuth.
                        now = time.perf_counter()
                        if now >= next_draw:
                            with viewer.lock():
                                viewer.cam.lookat[:] = data.qpos[base_adr : base_adr + 3]
                            viewer.sync()
                            next_draw = now + 1 / 60
                        next_frame += model.opt.timestep
                        time.sleep(max(0, next_frame - time.perf_counter()))
                        if next_frame < time.perf_counter() - 1:
                            next_frame = time.perf_counter()
            except (ValueError, RuntimeError) as error:
                failure = str(error)
                raise
            finally:
                data.ctrl[:] = 0
                data.qfrc_applied[:] = 0
                summary = {
                    "model_sha256": cfg.sha256,
                    "scene": str(args.scene.resolve()),
                    "tile": args.tile,
                    "physics_hz": p["update_rate"],
                    "policy_hz": p["rl_inference_frequency"],
                    "steps": steps,
                    "policy_calls": calls,
                    "resets": resets,
                    "simulated_seconds": steps * model.opt.timestep,
                    "final_base_xyz_m": data.qpos[base_adr : base_adr + 3].tolist(),
                    "worst_projected_gravity_z": worst_gravity_z,
                    "min_base_height_after_1s_m": None if math.isinf(min_height_after_1s) else min_height_after_1s,
                    "warning_counts": data.warning.number.tolist(),
                    "error": failure,
                    "scope": "MuJoCo policy playback only; no training or real-robot validation",
                }
                (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
                print(json.dumps(summary))


if __name__ == "__main__":
    main()
