"""Cloud training: Isaac Sim 5.1 / Isaac Lab 2.3.2 and RSL-RL 2.3.1. No local training is started automatically."""

import argparse
import copy
import hashlib
import importlib.metadata
import json
import sys
from datetime import datetime
from pathlib import Path


def main() -> None:
    from isaaclab.app import AppLauncher

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path("config/policies/srm_scut/policy_meta.yaml"))
    parser.add_argument("--stage", choices=["flat", "rough", "tunnel"], default="flat")
    parser.add_argument("--num-envs", type=int, default=None)
    parser.add_argument("--iterations", type=int, default=None, help="Additional learning iterations")
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument(
        "--check-only", action="store_true", help="Create task and take zero-action steps, no PPO update"
    )
    AppLauncher.add_app_launcher_args(parser)
    args = parser.parse_args()
    if importlib.metadata.version("rsl-rl-lib") != "2.3.1":
        raise RuntimeError(
            "This bridge uses RSL-RL 2.3.1; use the isolated cloud dependency overlay in CLOUD_TRAINING.md"
        )
    from wheelleg.mujoco_train import load_training_profile

    profile = load_training_profile(args.config.resolve())
    reference = (profile.path.parent / profile.settings["reference_assets"]).resolve()
    sys.path.insert(0, str(reference))
    if args.device is None:
        args.device = profile.settings["device"]
    app = AppLauncher(args).app
    try:
        import torch
        from rsl_rl.env import VecEnv
        from rsl_rl.runners import OnPolicyRunner

        from isaac.wheelleg_tasks.srm_scut_env import SrmScutEnv, make_env_cfg
        from wheelleg.actor import build_actor

        if not args.device.startswith("cuda") or not torch.cuda.is_available():
            raise RuntimeError("This entry is for cloud CUDA training; local CPU fallback is intentionally disabled")
        torch.manual_seed(profile.settings["seed"])
        n = profile.settings["num_envs"] if args.num_envs is None else args.num_envs
        iterations = profile.settings["iterations"] if args.iterations is None else args.iterations
        if n <= 0 or iterations <= 0:
            raise ValueError("num-envs and iterations must be positive")
        output = args.output or Path("runs/srm_scut") / datetime.now().strftime("%Y%m%d_%H%M%S")
        output.mkdir(parents=True, exist_ok=True)
        env = SrmScutEnv(make_env_cfg(profile, n, args.device), profile, stage=args.stage)
        try:
            env.reset()
            obs = env._get_observations()["policy"]
            if obs.shape != (n, 35) or not torch.isfinite(obs).all():
                raise ValueError("Initial observation does not satisfy SRM obs_v2")
            metadata = {
                "backend": "Isaac Lab",
                "stage": args.stage,
                "num_envs": n,
                "torch": torch.__version__,
                "cuda": torch.version.cuda,
                "gpu": torch.cuda.get_device_name(),
                "rsl_rl": "2.3.1",
                "isaaclab": importlib.metadata.version("isaaclab"),
                "physics_hz": profile.settings["control_hz"],
                "policy_hz": profile.settings["policy_hz"],
                "initialization": "random SRM Actor; no SCUT teacher weights"
                if args.resume is None
                else str(args.resume),
                "joint_names_srm_order": [env.robot.joint_names[i] for i in env.srm_joints],
                "body_bounds_source": profile.settings["geometry_source"],
            }
            (output / "environment.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
            (output / "policy_meta.yaml").write_bytes(profile.path.read_bytes())
            if args.check_only:
                for _ in range(10):
                    observations, rewards, _, _, _ = env.step(torch.zeros((n, 6), device=env.device))
                    if not torch.isfinite(observations["policy"]).all() or not torch.isfinite(rewards).all():
                        raise ValueError("Non-finite zero-action probe")
                print("Cloud environment probe passed; no PPO update was executed.")
                return

            class IsaacRslEnv(VecEnv):
                """Bridge Isaac Lab 2.3.2 dictionary outputs to the pinned RSL-RL 2.3.1 tuple API."""

                def __init__(self) -> None:
                    self.num_envs, self.num_actions = n, 6
                    self.device = env.device
                    self.max_episode_length = env.max_episode_length
                    self.episode_length_buf = env.episode_length_buf
                    self.cfg = dict(profile.settings)
                    self.unwrapped = self
                    self.step_dt = env.step_dt

                def get_observations(self) -> tuple[torch.Tensor, dict]:
                    return env._get_observations()["policy"], {"observations": {}}

                def reset(self) -> tuple[torch.Tensor, dict]:
                    env.reset()
                    return self.get_observations()

                def step(self, actions: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, dict]:
                    observations, rewards, terminated, truncated, extras = env.step(actions)
                    timeout = truncated & ~terminated
                    # Use the pre-reset TERMINAL observation, not RSL 2.3.1's previous-state value approximation.
                    final_values = runner.alg.policy.evaluate(env.final_observation).squeeze(-1).detach()
                    from wheelleg.tensor_training import bootstrap_timeout

                    rewards = bootstrap_timeout(rewards, final_values, timeout, train_cfg["algorithm"]["gamma"])
                    extras["observations"] = {}
                    # Do not supply time_outs: bootstrapping above must not be applied twice by RSL.
                    return observations["policy"], rewards, terminated | truncated, extras

            train_cfg = copy.deepcopy(profile.settings["runner"])
            runner = OnPolicyRunner(IsaacRslEnv(), train_cfg, log_dir=str(output), device=args.device)
            fresh_actor = build_actor(profile.policy).to(args.device)
            runner.alg.policy.actor.load_state_dict(fresh_actor.state_dict(), strict=True)
            if args.resume is not None:
                info = runner.load(str(args.resume))
                if (
                    info is None
                    or info["contract"] != "srm_scut_obs_v2"
                    or info["profile_sha256"] != hashlib.sha256(profile.path.read_bytes()).hexdigest()
                ):
                    raise ValueError("Resume requires this pipeline's final.pt with SRM/SCUT contract metadata")
                runner.current_learning_iteration += 1
            initial = torch.cat([p.detach().flatten() for p in runner.alg.policy.actor.parameters()]).clone()
            print(json.dumps(metadata))
            runner.learn(num_learning_iterations=iterations, init_at_random_ep_len=False)
            final = torch.cat([p.detach().flatten() for p in runner.alg.policy.actor.parameters()])
            if not torch.isfinite(final).all():
                raise ValueError("Trained actor contains non-finite weights")
            info = {
                "contract": "srm_scut_obs_v2",
                "stage": args.stage,
                "obs_version": 2,
                "profile_sha256": hashlib.sha256(profile.path.read_bytes()).hexdigest(),
            }
            runner.save(str(output / "final.pt"), infos=info)
            torch.save(
                {"actor_state_dict": runner.alg.policy.actor.cpu().state_dict(), **info}, output / "actor_state.pt"
            )
            torch.jit.script(runner.alg.policy.actor.cpu().eval()).save(str(output / "actor_scripted.pt"))
            (output / "training_summary.json").write_text(
                json.dumps(
                    {
                        **metadata,
                        "completed_iterations": iterations,
                        "last_iteration": runner.current_learning_iteration,
                        "actor_parameter_delta_l2": float((final - initial).norm()),
                        "actor_mean_parameters": int(initial.numel()),
                        "validation": "Training process completed; evaluate locomotion and tunnel success separately",
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            runner.writer.close()
        finally:
            env.close()
    finally:
        app.close()


if __name__ == "__main__":
    main()
