"""Plot actual RSL-RL TensorBoard scalars after cloud training; never synthesize missing curves."""

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

    events = EventAccumulator(str(args.run))
    events.Reload()
    tags = [
        tag
        for tag in [
            "Train/mean_reward",
            "Train/mean_episode_length",
            "Loss/value_function",
            "Loss/surrogate",
            "Metrics/success_fraction",
            "Metrics/failure_fraction",
        ]
        if tag in events.Tags()["scalars"]
    ]
    if not tags:
        raise ValueError("No training scalars found; run cloud training first")
    fig, axes = plt.subplots(len(tags), 1, figsize=(10, 3 * len(tags)), squeeze=False)
    for ax, tag in zip(axes[:, 0], tags, strict=True):
        values = events.Scalars(tag)
        ax.plot([v.step for v in values], [v.value for v in values])
        ax.set(title=tag, xlabel="PPO iteration")
        ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(args.run / "training_curves.png", dpi=160)
    print(args.run / "training_curves.png")


if __name__ == "__main__":
    main()
