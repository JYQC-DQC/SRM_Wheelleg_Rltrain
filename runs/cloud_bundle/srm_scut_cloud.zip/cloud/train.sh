#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/.cloud-deps:$PWD${PYTHONPATH:+:$PYTHONPATH}"
python -m tools.train_isaac_scut --headless "$@"
