#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD/.cloud-deps:$PWD${PYTHONPATH:+:$PYTHONPATH}"
# Defaults to SSH forwarding. For a platform-managed authenticated proxy, pass its required bind address explicitly.
python -m tensorboard.main --logdir "${1:-runs}" --port "${2:-6006}" --host "${3:-127.0.0.1}"
