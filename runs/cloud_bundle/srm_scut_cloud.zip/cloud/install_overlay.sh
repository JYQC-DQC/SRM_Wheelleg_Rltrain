#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Separate target directory: do not replace the image's Torch, NumPy, Isaac or CUDA packages.
python -m pip install --no-deps --upgrade --target .cloud-deps \
  rsl-rl-lib==2.3.1 mujoco==3.5.0 onnxruntime==1.20.0
export PYTHONPATH="$PWD/.cloud-deps:$PWD${PYTHONPATH:+:$PYTHONPATH}"
python -m tools.cloud_preflight
