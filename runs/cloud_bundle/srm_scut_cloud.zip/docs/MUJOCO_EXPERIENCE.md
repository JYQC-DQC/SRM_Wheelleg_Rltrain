# Windows MuJoCo 体验场地

本次先用华南虎 WheelBipe V14_2（含云台）体验。没有替换 `config/robot.yaml`，
没有把华南虎质量/几何/辨识参数作为 SRM 无云台底盘的参数，也没有修改两个参考仓库。

## 已实现与边界

已实现可独立加载、渲染、有碰撞的 MJCF 场地和机器人资产副本。
这不是 Isaac 场景的逐三角形转换，也不是 PPO 训练环境。
已新增独立的 Windows 策略入口，接通 SCUT normal-only ONNX、PD、气弹簧、腿电机动态响应，支持键盘和重置。
使用 MuJoCo 自带查看器直接打开 XML 时仍没有控制器，会自由下落；运行策略必须用下面的 `play_scut_policy`。

后续已另行编写云端 Isaac Lab 训练任务、奖励/终止/重置与 PPO 入口，见 [云端训练说明](CLOUD_TRAINING.md)。
训练只在算力平台执行，尚未完成云端验证；本文的旧 ONNX 播放入口仍只做推理。
原 `.pt` checkpoint 不保证能直接在另一训练器中续训；这里导入的 ONNX 用于推理，没有优化器和训练状态。
仅转换地形不能把 Isaac 训练代码直接变成 MuJoCo 训练代码。
本场地物理/PD 为 500 Hz。本次用户确认保留 SCUT 原策略的 50 Hz（每 10 个物理步推理）；
SRM 自研底盘的 100 Hz 策略约定没有改变。

## 加载华南虎策略（当前电脑已完成导入）

```bat
conda activate Mujoco
cd /d D:\SRM_Wheelleg_Rltrain
python -m tools.play_scut_policy
```

窗口内按 W/S 增减前进指令、A/D 增减偏航指令、T/G 增减高度；空格清零速度、R 重置、P 暂停。
指令是步进保持式，释放按键不会自动清零。关闭窗口退出。相机默认跟随机器人，可用鼠标调整视角。
这是 normal-only 平地/小陀螺模型，没有 jump 模式，不能声称已经学会跨越隧道。

无界面验证和指定出生地块：

```bat
python -m tools.play_scut_policy --headless --duration 10
python -m tools.play_scut_policy --headless --duration 10 --vx 0.5
python -m tools.play_scut_policy --tile grid_bars
```

其他地块的成功率尚未验证；提供 `--tile` 只是改变出生位置。
日志在 `runs/scut_play/<时间戳>/`：`trace.csv` 保存命令、机体位置、35D 观测和 6D 动作；
`summary.json` 保存运行步数、警告计数和姿态/高度摘要。R 重置后 `episode_time_s` 从 0 重新开始。

重新导入（例如复制仓库到另一台电脑后）：

```bat
python -m pip install -e ".[dev,play]"
python -m tools.import_scut_policy --reference D:\wheelbipe_ros2_sim2sim
```

导入器从原 YAML/Xacro 提取参数，模型副本放在 `runs/scut_experience/policy/`，
参数在 `config/policies/scut_experience/policy_meta.yaml`；运行时检查模型 SHA-256、输入输出名/形状/类型。
模型固定为 `obs float32[1,35] -> actions float32[1,6]`。不能随意换成其他 rough/RMA 权重。

实现参考 SCUT `state_rl.cpp`、`template_ros2_controller.cpp` 和 MuJoCo bridge 的 `mujoco_system.cpp`：
四腿位置 PD、轮速度 PD、源控制器和硬件限幅、腿电机二阶响应/力矩变化率/速度衰减、线性气弹簧及粘性阻尼。
复现默认 `hardware_pd_vel` / 无滤波 / 无观测噪声延迟路径；没有复刻 ROS FSM、DT7 或通信超时语义。
通过 `qfrc_applied` 施加最终力，不同时使用 XML motor 的 ctrl，避免重复施力。
物理仍使用本场地 0.002 s / implicitfast；没有证明与原 ROS/Isaac 的数值轨迹完全一致。
源代码许可见 `docs/SCUT_PLAYER_LICENSES.txt`；原模型/资产许可随模型副本保存。

本机策略验证（2026-11-09，ONNX Runtime 1.20.0 CPU）：

| 运行 | 结果 |
| --- | --- |
| 平地零速度 30 s | 15000 步 / 1500 次推理，无引擎警告，机体保持直立；位置漂移约 1.34 m，不是精确原地保持 |
| 平地前进命令 0.5 m/s、10 s | 5000 步 / 500 次推理，无引擎警告；最终位置约 (-0.274,-0.465,0.225) m，起点 (-3.8,0,0.6) m |
| 偏航命令 0.5 rad/s、10 s | 5000 步 / 500 次推理，无引擎警告，机体保持直立；未评估偏航跟踪精度 |
| GUI 路径、3 s | 1500 步 / 150 次推理，正常退出，无引擎警告；未自动验证键盘按键 |

这是短时仿真推理检查，不是训练、实机或所有障碍通过验证。模型本身和仿真匹配仍有误差。

策略接入后的仓库检查：`python -m pytest -q` 为 `17 passed, 1 skipped`；
`python -m ruff check .` 为 `All checks passed!`；
`python -m ruff format --check .` 为 `14 files already formatted`（Ruff 0.14.4）。
跳过项仍是缺少 Torch 的既有 Actor 测试；新增检查包含真实 ONNX 推理、旋转后重力/角速度投影、
八关节命名映射、上一动作与 50 Hz 降采样，以及气弹簧/电机响应数值行为。

## 打开

在 Anaconda Prompt：

```bat
conda activate Mujoco
cd /d D:\SRM_Wheelleg_Rltrain
python -m mujoco.viewer --mjcf="D:\SRM_Wheelleg_Rltrain\runs\scut_experience\scene.xml"
```

按空格暂停，鼠标左键拖动旋转、滚轮缩放。场地较大，初始是全景。
`runs/scut_experience/overview.png` 和 `robot.png` 是本机 MuJoCo 实际渲染图。
绿色区域是跳隧道的后方地面落地区，紫色屋顶不是成功落地区。

## 修改和重新生成

编辑 `config/scenes/scut_experience.yaml`；尺寸单位 m，坡度为高/水平距离。
场地参数集中在该独立配置内，与真实底盘参数隔离。

```bat
python -m pip install -e ".[dev,sim]"
python -m tools.build_mujoco_scene --reference D:\wheelbipe_ros2_sim2sim
```

输出默认在 `runs/scut_experience/`。包含 `scene.xml`、3 个高度场、21 个机器人 STL、
许可证、配置快照和 `terrain_manifest.json`。保留整个文件夹即可迁移；只复制 XML 会缺网格/高度场。
manifest 包含各地块的中心、出生点和隧道落地区坐标，方便后续 reset/reward 接入。
当前只生成落地区元数据；尚无自动成功判定或奖励实现。

## 地块布局与来源

坐标：x、y 水平，z 向上；每格 9×9 m，行内向 +x 排列、换行向 +y。
机器人出生在 flat 地块的 x=-3.8 m、y=0，z 保留参考模型的 0.6 m。
其他地块边缘的青色点为建议出生点；它们只是显示标记。

| 地块中心 (x,y) | 内容 | 参考与差异 |
| --- | --- | --- |
| (0,0) | 平地 | SCUT plane 家族 |
| (9,0) | 凸金字塔坡面 | 选用低坡度范围中的 0.10，最高 0.35 m |
| (18,0) | 凹金字塔坡面 | 采用相同坡度；抬高盆地外缘，中心为 z=0，不在全局地面下挖坑 |
| (27,0) | 金字塔台阶 | 级高 0.015 m、级宽 0.1 m、平台宽 1 m；实体 box 垂直立面 |
| (0,9) | 凹金字塔台阶 | 级高 0.015 m、级宽 0.1 m、中央平地宽 2 m；抬高外缘 |
| (9,9) | 井字矮障碍 | 每轴 4 根，宽 0.12 m、高 0.025 m；规则排列，未复刻原随机布局 |
| (18,9) | 随机粗糙地形 | 高 0–0.03 m、粗采样 0.2 m、插值后 0.1 m；不是 Isaac 原始随机样本 |
| (27,9) | 起跳坡、实体隧道、后方落地标记 | 自定义体验尺寸，不是官方赛场实测尺寸；必须完整越过后在后方地面落地 |

原始地形源：
`D:/wheeled-legged_RL/source/agent_tasks/agent_tasks/manager/mdp/isaaclab/terrains.py`，
重点是 `RM_ROTATION_TERRAINS_CFG_99` 和各低难度子地形。
原配置为 10×10 地块并开启 curriculum；这里缩为 2×4 个固定地块，没有实现课程调度。
本实现独立生成 MuJoCo 几何；没有导入 Isaac Lab，亦不要求安装它。

读取时训练仓库 commit：`1a26356d6f591734d4f6f666f5cead1a6925da67`。
机器人源：`wheelbipe_ros2_sim2sim`，commit `dd367bf78c7e393d811595edeb4affe253156c95`，
`src/resources/robot_descriptions/wheelbipeV14_2/mjcf/wheelbipeV14_2.xml`。
机器人关节、质量惯量、闭链约束、执行器限幅、弹簧结构保留原模型；只重写网格路径与出生 x/y。
物理步长/积分器和世界视觉配置由本场景设置，未验证与 Isaac 接触动力学一致。
SCUT 机器人、网格许可随输出保存。场地接触参数为体验用配置，未经实物辨识。

## 本机验证（2026-11-09）

Python 3.12.16 / MuJoCo 3.5.0。实际加载：22 bodies、179 geoms、3 heightfields、8 actuators。
原机器人无控制器模拟 1000 步（2 s），状态有限，MuJoCo warning 计数全为 0。
这只是被动下落和引擎加载检查，不是站立、运动、跳跃、策略或 GPU 训练验证。

```text
python -m pytest -q
13 passed, 1 skipped
python -m ruff check .
All checks passed!
python -m ruff format --check .
10 files already formatted
```

Ruff 使用 0.14.4。初装 0.17.4 的格式检查还扫描到既有 `docs/CODING_GUIDE.md` 的代码块格式差异；
没有修改那份无关指南。当前环境没有 Torch，既有 Actor 测试模块跳过；未修改 Anaconda base。
新增数值检查覆盖高度范围、随机种子、MuJoCo 地形射线碰撞高度、屋顶与后方落地区分离及物理步进。
