# 云端从零训练 SRM 网络控制华南虎机器人

## 这次训练的含义

机器人是 SCUT WheelBipe V14_2（保留原 USD 闭链、弹簧和云台）。
学习方案是 SRM 的 obs_v2、35→256→128→64→6 / ELU Actor 和 PPO。
Actor 从随机权重初始化，不加载华南虎 ONNX、checkpoint、教师动作或优化器。
不是训练 SRM 真实无云台底盘；`config/robot.yaml` 的缺失实测量仍保持 null。

训练只在用户提供的算力平台运行：Ubuntu 24.04、Isaac Sim 5.1、Isaac Lab 2.3.2。
本地只做代码/数值检查、打包，之后用 MuJoCo 播放云端训练结果。本次没有执行本地 PPO 更新或 GPU 训练。
这是新任务的待云端验证实现；不能把静态检查通过当成 Isaac 运行、训练收敛或跳跃成功。

## 需要什么

| 项目 | 来源 / 用途 |
| --- | --- |
| 已有 Isaac Sim 5.1 / Isaac Lab 2.3.2 镜像 | GPU 并行物理仿真；保持镜像自带的 Python、Torch、CUDA 组合 |
| 可用 NVIDIA CUDA GPU | 云端物理与 PPO；具体环境数按实际显存和预检结果调整，不预报训练速度 |
| 本仓库训练配置、任务、启动脚本 | `config/policies/srm_scut/policy_meta.yaml`、`isaac/wheelleg_tasks/srm_scut_env.py` |
| 华南虎机器人 USD 与资产代码 | 打包时复制到 `reference/agent_world/`，不改参考仓库 |
| RSL-RL 2.3.1 | 使用已经核对过的官方 PPO/Runner API；独立覆盖目录，不替换镜像核心依赖 |
| TensorBoard、GitPython、onnx 等 | 版本预检会指出镜像缺少的模块；只补缺失包 |
| 持久存储 | 保存配置快照、环境版本、TensorBoard、完整 checkpoint 和推理 Actor |

当前包没有预训练教师权重。原 SCUT 参数 YAML 只提供参考机器人 PD、弹簧和电机动态参数，
训练加载时不读取或验证原 ONNX 文件，也不会创建 ONNX 推理 session。

## 本地上传包

本次已生成 `runs/cloud_bundle/srm_scut_cloud.zip`。如代码更新后需要重打包：

```bat
conda activate Mujoco
cd /d D:\SRM_Wheelleg_Rltrain
python -m tools.package_cloud_training --reference D:\wheeled-legged_RL
```

ZIP 内有代码、配置、参考 USD 资产、MuJoCo 对照资产、许可证与文件 SHA-256 清单。
无需上传整个 Anaconda 环境或预训练权重。请放在算力平台的持久磁盘，并在解压根目录运行命令。

## 云端安装与预检

先进入镜像原有 Isaac/Python 环境，确认 `python` 就是镜像原来的解释器。
不要执行无版本约束的 `pip install --upgrade torch`、更换 CUDA 或重装 Isaac。

```bash
unzip srm_scut_cloud.zip -d srm_scut_cloud
cd srm_scut_cloud
bash cloud/install_overlay.sh
```

脚本仅将固定的 RSL-RL/MuJoCo/ONNX Runtime 放到 `.cloud-deps/`。
预检记录 `runs/cloud_preflight.json`，检查版本、CUDA 与资产，缺失会明确失败。
如果镜像缺 `git` 模块，它对应 `GitPython` 包；缺其他依赖时按预检补该包，
优先在 `.cloud-deps/` 中用 `--no-deps --target` 安装，不升级镜像已有核心包。
如果 TensorBoard/Matplotlib 的依赖不全，先完成依赖预检，不能跳过后冒充可运行。

新终端需要重新设置覆盖目录：

```bash
export PYTHONPATH="$PWD/.cloud-deps:$PWD${PYTHONPATH:+:$PYTHONPATH}"
python -m tools.cloud_preflight
```

首次先只做 1 环境、10 步的 Isaac 环境检查，不更新 PPO：

```bash
bash cloud/train.sh --check-only --num-envs 1 --output runs/cloud_env_probe
```

这一步用于发现 USD/闭链、关节命名、接触传感器、PhysX、云镜像 API 和初始状态问题。
尤其应在平台查看含云台 USD 的关节和 body 帧是否与打包的 MJCF 几何包围球一致；
命名不匹配会报错，命名一致仍不能替代几何帧审计。跳隧道阶段暂不能声明已验收。

## 从零训练

先运行指南要求的 512 环境、200 轮云端冒烟，并生成真实曲线：

```bash
bash cloud/train.sh --stage flat --num-envs 512 --iterations 200 --output runs/scut_srm_smoke
python -m tools.plot_training runs/scut_srm_smoke
```

检查 `training_curves.png`、`environment.json`、`training_summary.json` 和 TensorBoard。
应确认无 NaN/物理错误，Actor 参数确实变化、失败率和回合长度合理；200 轮不能保证已经学会行走。
这轮验证尚未在云平台执行，本地没有生成或模拟训练曲线。

之后才开始正式平地训练，下面的规模是配置起点，不是显存或效果保证：

```bash
bash cloud/train.sh --stage flat --num-envs 4096 --iterations 2000 --output runs/scut_srm_flat
```

若环境检查或冒烟已显示显存/PhysX 缓冲不足，应先减少环境数并记录实际规模。
不要用加大随机化来掩盖模型错误；当前没有加入参数域随机化。

仅在平地策略经过速度/姿态评测后，再恢复同一方案的完整 checkpoint：

```bash
bash cloud/train.sh --stage rough --num-envs 512 --iterations 2000 \
  --resume runs/scut_srm_flat/final.pt --output runs/scut_srm_rough

bash cloud/train.sh --stage tunnel --num-envs 512 --iterations 2000 \
  --resume runs/scut_srm_rough/final.pt --output runs/scut_srm_tunnel
```

阶段切换是显式课程，不自动宣称满足升级门槛。
`--iterations` 表示本次追加轮数；`--resume` 恢复网络、优化器和已完成迭代，检查合同与配置 hash。
不带 `--resume` 始终随机初始化，不会偷偷续训原华南虎权重。
恢复不包含模拟器瞬时状态和全部随机数进度，不保证中断前后逐步同轨。
只使用本流水线的 `final.pt` 恢复；其他网络或旧 50 Hz 策略不能混用。

## 观测、动作与奖励

- 500 Hz 物理/PD，100 Hz 新策略。原华南虎 50 Hz ONNX 体验入口保持原样。
- 35D：command(3)、height(1)、机体系角速度(3)、投影重力(3)、相对关节角(6)、关节速度(6)、上一原始动作(6)、mode(7)。
- 唯一顺序仍由 `wheelleg/observation.py::OBS_FIELDS` 定义，Torch 与 NumPy 路径共同使用。
- SRM 通道为 LF、LR、LW、RF、RR、RW；云端按真实 USD 关节名查找，不假设 USD 内部索引。
- 四腿是位置残差、两轮是速度目标；动作裁剪发生在控制执行端，上一动作观测保留裁剪前输出。
- 显式力矩已包含 PD/弹簧/电机响应，主动 actuator 的额外 PD/弹簧阻尼置零以避免重复；保留原被动结构与云台 actuator。
- 奖励按项记录：前进/转向跟踪、直立、高度、竖直速度、滚转俯仰角速度、力矩、动作变化、失败。
- 失败包括倾倒、机体过低、越出练习区；超时用重置前终态观测 bootstrap，禁止重复 bootstrap。

跳隧道的新增约束：必须在隧道宽度内腾空，整机保守包围球从隧道后边界上方完整越过；
之后整机进入后方落地区、两轮接触地面且此前未接触屋顶，才给成功奖励。
屋顶接触终止并罚分；不奖励顶面落地，也不把绕路后走进落地区算作越过。
此判据已做独立张量数值测试，但 USD 接触过滤器和包围球对应关系仍需云端实际检查。

当前 mode 固定 normal；跳跃需要从起跳坡、指令与物理响应中学到，并没有教师动作或单独 jump 按钮。
这一任务是否能收敛尚未验证。各权重、超参数和自定义场地尺寸都是设计起点，不是实测最优值。
Isaac rough 阶段为 6×6 低矮 box 练习区；它不是原华南虎地形的逐点转换，也不是 MuJoCo 高度场的逐三角形等价物。

## TensorBoard 实时监控

配置中已启用 `logger: tensorboard`，RSL-RL 将事件写到训练命令 `--output` 指定的目录。
监控不需要修改奖励函数或重新导出模型；无需安装完整 TensorFlow。
`--check-only` 不创建 PPO 日志，只有真正训练后才有学习曲线；日志可能延迟约 10 秒刷到磁盘。

在云端另开一个终端，进入项目根目录，启动：

```bash
bash cloud/tensorboard.sh runs 6006
```

`runs` 会递归显示其中不同训练运行；只看一次运行可改成 `runs/scut_srm_smoke`。
默认只监听云端回环地址。使用平台提供的 SSH 连接信息，在本地 Windows PowerShell 建立隧道：

```powershell
ssh -N -L 16006:127.0.0.1:6006 -p SSH端口 用户名@SSH地址
```

然后在本地浏览器打开 `http://127.0.0.1:16006`。保持此 PowerShell 和云端 TensorBoard 进程运行。
这条命令的 SSH 用户/地址/端口与正常登录相同，继续复用原来的密码或密钥，不需要额外申请 TensorBoard 密钥。
这里用本地 16006 避免与已有的本地 TensorBoard 6006 冲突。

若已用 VS Code Remote-SSH 连接，在“端口/Ports”中转发云端 6006，使用界面显示的本地地址即可。
如果平台禁用 SSH 转发，改用平台自带的 TensorBoard 或认证 Web 服务入口；绑定地址按平台要求配置。
仅在该入口明确要求时可运行 `bash cloud/tensorboard.sh runs 6006 0.0.0.0`，访问平台给出的服务 URL。

建议先看以下 Scalars：

| 指标 | 用途 |
| --- | --- |
| `Train/mean_reward` | 回合总奖励趋势，不单凭上升就认定控制成功 |
| `Train/mean_episode_length` | 能否维持更长回合，结合失败率判断 |
| `Reward/*` | 各项奖励贡献，发现被某一项主导的问题 |
| `Metrics/failure_fraction` | 每步失败的环境比例 |
| `Metrics/success_fraction` | 隧道阶段每步成功比例；平地阶段没有成功事件 |
| `Loss/value_function`、`Loss/surrogate` | 价值与策略优化状态 |
| `Policy/mean_noise_std`、`Loss/learning_rate` | 探索噪声与当前学习率 |

没有图时先确认已经启动训练、`--logdir` 对应输出目录，并存在 `events.out.tfevents.*`。
回合尚未结束时可能还没有 `Train/mean_reward`，应先看已有的 Loss/Reward 指标。
TensorBoard 曲线表示训练过程，不能替代 Isaac/MuJoCo 的动作评测或实机验收。

## 训练产物与本地播放

每次运行会保存：`environment.json`、`policy_meta.yaml`、TensorBoard 事件、`model_*.pt`、
带合同和配置 hash 的 `final.pt`、`actor_state.pt` 和 `actor_scripted.pt`。
完整恢复用 `final.pt`；本地 MuJoCo 推理用 `actor_state.pt`。不要将新权重交给旧 `play_scut_policy`。

下载产物后，在本地运行（只推理，不训练）：

```bat
conda activate Mujoco
cd /d D:\SRM_Wheelleg_Rltrain
python -m tools.play_srm_scut --checkpoint runs\从云端下载的目录\actor_state.pt --duration 20
```

必须保留相同的配置文件内容；配置 hash 不一致会拒绝加载。
本地 MuJoCo 的动力学、初始下落高度和云台自由度与 Isaac USD 仍存在差异，
不能把 Isaac 的回报曲线上升等同于 MuJoCo 或真实机器人成功。

## 当前完成状态

已编写代码、参数、版本适配、打包、预检、云端启动、恢复、导出和本地播放入口。
本地数值测试不需要启动 Isaac；没有在本机执行 PPO 更新，也没有云端 GPU 训练记录。
512×200 冒烟、曲线、闭链运行、接触过滤器及最终运动效果都必须由云端实际运行确认。
原训练仓库、原部署仓库与 SRM 实物参数不作修改。

本地检查实际输出：

```text
python -m pytest -q
23 passed
python -m ruff check .
All checks passed!
python -m ruff format --check .
24 files already formatted
```

Python 3.12.16 / Torch 2.7.0+cpu / MuJoCo 3.5.0 / RSL-RL 2.3.1。
本地为验证接口补装了 CPU Torch 与 RSL-RL 等依赖；Anaconda base 没有修改，也没有执行 PPO 学习轮次。
Isaac 任务 API 核对来源：
[Isaac Lab 2.3.2 DirectRLEnv](https://github.com/isaac-sim/IsaacLab/blob/v2.3.2/source/isaaclab/isaaclab/envs/direct_rl_env.py)、
[对应 RSL 封装接口](https://github.com/isaac-sim/IsaacLab/blob/v2.3.2/source/isaaclab_rl/isaaclab_rl/rsl_rl/vecenv_wrapper.py)。
