from pathlib import Path
from types import MappingProxyType

import numpy as np
import pytest
import yaml

pytest.importorskip("mujoco")
pytest.importorskip("onnxruntime")

from wheelleg.scut_policy import (  # noqa: E402
    ScutConfig,
    ScutController,
    load_scut_config,
    motor_step,
    scut_observation,
    spring_force,
)


@pytest.fixture
def cfg():
    path = Path(__file__).resolve().parents[1] / "config/policies/scut_experience/policy_meta.yaml"
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    return ScutConfig(
        Path("unused.onnx"),
        raw["sha256"],
        tuple(raw["joint_names"]),
        MappingProxyType(raw["parameters"]),
        MappingProxyType(raw["actuator"]),
        MappingProxyType(raw["spring"]),
        MappingProxyType(raw["keyboard"]),
        tuple(raw["hardware_effort_min"]),
        tuple(raw["hardware_effort_max"]),
        tuple(raw["normal_mode"]),
    )


def test_all_observation_slots(cfg):
    obs = scut_observation(
        cfg,
        np.array([1, 0, 2, 0.3]),
        np.array([2, 4, 6]),
        np.array([0, 0, -1]),
        np.arange(8, dtype=float),
        np.arange(10, 18, dtype=float),
        np.arange(20, 26, dtype=float),
    )
    np.testing.assert_allclose(
        obs[0],
        [
            1,
            0,
            2,
            1.5,
            1,
            2,
            3,
            0,
            0,
            -1,
            0,
            1,
            2,
            3,
            0,
            0,
            1,
            1.1,
            1.2,
            1.3,
            1.4,
            1.5,
            20,
            21,
            22,
            23,
            24,
            25,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
        ],
    )
    assert obs.dtype == np.float32
    assert obs.shape == (1, 35)
    with pytest.raises(ValueError, match="finite 35D"):
        scut_observation(
            cfg, np.array([np.nan, 0, 0, 0.3]), np.zeros(3), np.zeros(3), np.zeros(8), np.zeros(8), np.zeros(6)
        )


def test_spring_endpoints_clamping_and_damping(cfg):
    positions = np.array([-0.01, -0.005, 0.07, 0.08])
    np.testing.assert_allclose(spring_force(cfg, positions, np.zeros(4)), [650, 650, 450, 450])
    np.testing.assert_allclose(spring_force(cfg, positions, np.array([1, -1, 1, -1])), [150, 1150, -50, 950])


def test_motor_response_slew_and_saturation(cfg):
    # 1500 Nm/s slew bound with 0.002 s integration gives at most 3 Nm in the first step.
    effort, rate = motor_step(cfg, np.full(4, 50.0), np.zeros(4), np.zeros(4), np.zeros(4), 0.002)
    np.testing.assert_allclose(effort, 3)
    np.testing.assert_allclose(rate, 1500)
    clipped, rate = motor_step(cfg, np.full(4, 100.0), np.zeros(4), np.full(4, 54.0), np.full(4, 1500.0), 0.002)
    np.testing.assert_allclose(clipped, 54)
    np.testing.assert_allclose(rate, 0)
    # Motor speed droop has a lower gain bound of 0.55.
    effort = np.full(4, 5.5)
    same, _ = motor_step(cfg, np.full(4, 10.0), np.full(4, 100.0), effort, np.zeros(4), 0.002)
    np.testing.assert_allclose(same, effort)


def test_real_policy_mapping_rotation_and_decimation():
    import mujoco

    root = Path(__file__).resolve().parents[1]
    scene = root / "runs/scut_experience/scene.xml"
    config = root / "config/policies/scut_experience/policy_meta.yaml"
    if not scene.exists() or not (root / "runs/scut_experience/policy/policy.onnx").exists():
        pytest.skip("Generate scene and import the official ONNX artifact to run this integration check")
    cfg = load_scut_config(config)
    model = mujoco.MjModel.from_xml_path(str(scene))
    data = mujoco.MjData(model)
    control = ScutController(model, cfg)
    # Rotate 90 degrees about x: world gravity projects to negative body y.
    data.qpos[3:7] = [2**-0.5, 2**-0.5, 0, 0]
    data.qvel[3:6] = [1, 0, 0]
    data.qpos[control.qadr[:6]] = [0.1, 0.2, 0.3, 0.4, 17, -19]
    mujoco.mj_forward(model, data)
    command = np.array([0, 0, 0, 0.22])
    obs = control.observe(data, command)
    np.testing.assert_allclose(obs[0, 4:10], [0.5, 0, 0, 0, -1, 0], atol=1e-6)
    np.testing.assert_allclose(obs[0, 10:16], [0.1, 0.2, 0.3, 0.4, 0, 0], atol=1e-6)
    assert control.step(data, command)
    previous = control.action.copy()
    assert np.isfinite(previous).all()
    assert data.ctrl.sum() == 0
    for _ in range(9):
        assert not control.step(data, command)
    assert control.step(data, command)
    np.testing.assert_allclose(control.observation[0, 22:28], previous)
    control.reset()
    np.testing.assert_array_equal(control.action, np.zeros(6))
    assert control.steps == 0
