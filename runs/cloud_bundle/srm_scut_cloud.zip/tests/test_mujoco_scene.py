import json
from pathlib import Path

import numpy as np
import pytest
import yaml

from tools.build_mujoco_scene import build_scene, heightfield

CONFIG = Path(__file__).resolve().parents[1] / "config/scenes/scut_experience.yaml"


def test_terrain_heights_and_seed():
    cfg = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    slope, basin = cfg["tiles"][1:3]
    up = heightfield(slope, cfg, np.random.default_rng(42))
    down = heightfield(basin, cfg, np.random.default_rng(42))
    mid = up.shape[0] // 2
    assert up[mid, mid] == pytest.approx(0.35)
    assert down[mid, mid] == pytest.approx(0)
    np.testing.assert_allclose(up + down, 0.35, atol=1e-12)
    rough = cfg["tiles"][6]
    a = heightfield(rough, cfg, np.random.default_rng(42))
    b = heightfield(rough, cfg, np.random.default_rng(42))
    np.testing.assert_array_equal(a, b)
    assert 0 <= a.min() <= a.max() <= rough["max_height_m"]
    assert np.all(a[[0, -1], :] == 0)


def test_scene_collision_heights_and_ground_landing(tmp_path):
    mujoco = pytest.importorskip("mujoco")
    reference = tmp_path / "reference"
    robot = reference / "src/resources/robot_descriptions/wheelbipeV14_2"
    (robot / "mjcf").mkdir(parents=True)
    (robot / "meshes").mkdir()
    (robot / "mjcf/wheelbipeV14_2.xml").write_text(
        '<mujoco><asset/><worldbody><body name="base_link" pos="0 0 .6">'
        '<freejoint/><geom type="box" size=".1 .1 .1" mass="1"/>'
        "</body></worldbody></mujoco>",
        encoding="utf-8",
    )
    for path in [reference / "LICENSE", reference / "THIRD_PARTY_NOTICES.md", robot / "meshes/ASSET_LICENSE.md"]:
        path.write_text("Test fixture", encoding="utf-8")
    scene = build_scene(CONFIG, reference, tmp_path / "course")
    model = mujoco.MjModel.from_xml_path(str(scene))
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)

    def surface(x, y):
        geom = np.array([-1], dtype=np.int32)
        distance = mujoco.mj_ray(model, data, np.array([x, y, 2.0]), np.array([0.0, 0.0, -1.0]), None, 1, -1, geom)
        assert distance >= 0
        return 2 - distance, mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, geom[0])

    assert surface(9, 0)[0] == pytest.approx(0.35, abs=1e-6)
    assert surface(18, 0)[0] == pytest.approx(0, abs=1e-6)
    assert surface(27, 0)[0] == pytest.approx(0.45, abs=1e-6)
    assert surface(0, 9)[0] == pytest.approx(0, abs=1e-6)
    assert surface(27, 9) == pytest.approx((0.35, "tunnel_roof"))
    assert surface(29, 9)[0] == pytest.approx(0, abs=1e-6)
    manifest = json.loads((scene.parent / "terrain_manifest.json").read_text(encoding="utf-8"))
    assert manifest["tiles"][-1]["landing_x_range_m"][0] > 27 + 0.9 / 2
    assert model.opt.timestep == 0.002
    for _ in range(100):
        mujoco.mj_step(model, data)
    assert np.isfinite(data.qpos).all()
    assert not data.warning.number.any()
