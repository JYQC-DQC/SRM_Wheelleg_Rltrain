"""SRM obs_v2 / actor contract on the SCUT reference robot, using batched MuJoCo CPU rollout."""

import json
import math
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

import mujoco
import numpy as np
import torch
import yaml
from mujoco.rollout import Rollout
from rsl_rl.env import VecEnv

from . import training_rewards as terms
from .config import PolicyConfig, load_policy
from .observation import pack_observation
from .scut_policy import ScutConfig, load_scut_config, scut_lowlevel


@dataclass(frozen=True)
class TrainingProfile:
    path: Path
    policy: PolicyConfig
    physics: ScutConfig
    scene: Path
    settings: MappingProxyType


def load_training_profile(path: Path) -> TrainingProfile:
    policy = load_policy(path)
    raw = yaml.safe_load(path.read_text("utf-8"))["training"]
    for key in ["control_hz", "policy_hz", "num_envs", "rollout_threads", "torch_threads", "iterations"]:
        if type(raw[key]) is not int or raw[key] <= 0:
            raise ValueError(f"{path}: training.{key} must be a positive integer")
    if raw["control_hz"] % raw["policy_hz"]:
        raise ValueError(f"{path}: policy frequency must divide physical frequency")
    if sorted(raw["source_to_srm"]) != list(range(6)):
        raise ValueError(f"{path}: source_to_srm must permute six channels")
    if raw["leg_indices"] != [0, 1, 3, 4] or raw["wheel_indices"] != [2, 5]:
        raise ValueError(f"{path}: expected the SRM joint ordering")
    for key in ["episode_seconds", "height_command_m", "tracking_variance", "height_variance_m2", "tile_half_extent_m"]:
        if not np.isfinite(raw[key]) or raw[key] <= 0:
            raise ValueError(f"{path}: training.{key} must be finite and positive")
    if policy.action_clip is None:
        raise ValueError(f"{path}: training requires an explicit action_clip")
    if raw["runner"]["policy"]["actor_hidden_dims"] != list(policy.hidden_dims):
        raise ValueError(f"{path}: PPO actor dimensions must match the SRM actor")
    if raw["runner"]["policy"]["activation"] != policy.activation:
        raise ValueError(f"{path}: PPO actor activation must match SRM")
    # Scratch training imports ONLY the physics parameter profile, not a teacher model or its weights.
    physics = load_scut_config((path.parent / raw["scut_parameters"]).resolve(), verify_model=False)
    if physics.parameters["update_rate"] != raw["control_hz"]:
        raise ValueError(f"{path}: control frequency differs from SCUT physics configuration")
    return TrainingProfile(path, policy, physics, (path.parent / raw["scene"]).resolve(), MappingProxyType(raw))


def rotate_inverse(quaternion: np.ndarray, vector: np.ndarray) -> np.ndarray:
    """Unit quaternions wxyz; world vectors -> body vectors, batches (N,4)/(N,3)."""
    qv = -quaternion[:, 1:]
    t = 2 * np.cross(qv, vector)
    return vector + quaternion[:, :1] * t + np.cross(qv, t)


class MujocoTrainEnv(VecEnv):
    def __init__(self, profile: TrainingProfile, *, stage: str = "flat", num_envs: int | None = None) -> None:
        self.profile, self.cfg = profile, dict(profile.settings)
        self.device = "cpu"
        self.num_envs, self.num_actions = num_envs or self.cfg["num_envs"], 6
        if self.num_envs <= 0:
            raise ValueError("num_envs must be positive")
        self.stage = self.cfg["stages"][stage]
        self.step_dt = 1 / self.cfg["policy_hz"]
        self.max_episode_length = math.ceil(self.cfg["episode_seconds"] / self.step_dt)
        self.episode_length_buf = torch.zeros(self.num_envs, dtype=torch.long)
        self.unwrapped = self
        self.rng = np.random.default_rng(self.cfg["seed"])
        root = ET.parse(profile.scene).getroot()
        for asset in root.findall("asset/*[@file]"):
            asset.set("file", str((profile.scene.parent / asset.attrib["file"]).resolve()))
        original = mujoco.MjModel.from_xml_path(str(profile.scene))
        sensor = root.find("sensor")
        robot_geoms = root.findall(".//body/geom")
        for i, geom in enumerate(robot_geoms):
            ET.SubElement(sensor, "framepos", name=f"train_geom_{i}", objtype="geom", objname=geom.attrib["name"])
        self.geom_radii = np.array([original.geom(g.attrib["name"]).rbound[0] for g in robot_geoms])
        for side in ["left", "right"]:
            body = root.find(f".//body[@name='{side}_wheel_link']")
            geom = body.find(f"geom[@name='{side}_wheel_link_collision']")
            radius = original.geom(f"{side}_wheel_link_collision").rbound[0]
            ET.SubElement(
                body,
                "site",
                name=f"train_touch_{side}",
                type="sphere",
                size=str(radius),
                pos=geom.attrib["pos"],
                rgba="0 0 0 0",
            )
            ET.SubElement(sensor, "touch", name=f"train_touch_{side}", site=f"train_touch_{side}")
        roof = root.find("worldbody/geom[@name='tunnel_roof']")
        if roof is None:
            raise ValueError("Training scene must include the tunnel roof for explicit roof-contact rejection")
        ET.SubElement(
            root.find("worldbody"),
            "site",
            name="train_roof_touch",
            type="box",
            pos=roof.attrib["pos"],
            size=roof.attrib["size"],
            rgba="0 0 0 0",
        )
        ET.SubElement(sensor, "touch", name="train_roof_touch", site="train_roof_touch")
        self.model = mujoco.MjModel.from_xml_string(ET.tostring(root, encoding="unicode"))
        if not np.isclose(self.model.opt.timestep, 1 / self.cfg["control_hz"]):
            raise ValueError("Scene timestep differs from the training contract")
        self.data_pool = [mujoco.MjData(self.model) for _ in range(self.cfg["rollout_threads"])]
        self.pool = Rollout(nthread=self.cfg["rollout_threads"])
        self.permutation = np.array(self.cfg["source_to_srm"])
        self.inverse_permutation = np.argsort(self.permutation)
        joint_ids = [self.model.joint(n).id for n in profile.physics.joint_names]
        self.qadr, self.vadr = self.model.jnt_qposadr[joint_ids], self.model.jnt_dofadr[joint_ids]
        source_scale = np.array(profile.physics.parameters["joint_action_scale"][:6])
        if not np.allclose(source_scale[self.permutation], profile.policy.action_scales):
            raise ValueError("Training action scales differ from the imported SCUT actuator profile")
        self.geom_sensor_adr = self.model.sensor("train_geom_0").adr[0]
        self.wheel_sensor_adr = self.model.sensor("train_touch_left").adr[0]
        self.roof_sensor_adr = self.model.sensor("train_roof_touch").adr[0]
        self.geom_count = len(robot_geoms)
        manifest = json.loads((profile.scene.parent / "terrain_manifest.json").read_text("utf-8"))
        self.tile = next(t for t in manifest["tiles"] if t["name"] == self.stage["tile"])
        data = self.data_pool[0]
        self.template = np.zeros(mujoco.mj_stateSize(self.model, mujoco.mjtState.mjSTATE_FULLPHYSICS))
        mujoco.mj_getState(self.model, data, self.template, mujoco.mjtState.mjSTATE_FULLPHYSICS)
        self.state = np.tile(self.template, (self.num_envs, 1))
        self.previous = np.zeros((self.num_envs, 6))
        self.motor_effort, self.motor_rate = np.zeros((self.num_envs, 4)), np.zeros((self.num_envs, 4))
        self.first = np.ones(self.num_envs, dtype=bool)
        self.roof_touched = np.zeros(self.num_envs, dtype=bool)
        self.cleared_tunnel = np.zeros(self.num_envs, dtype=bool)
        self.previous_min_x = np.full(self.num_envs, -np.inf)
        self.command = np.zeros((self.num_envs, 3))
        self.height_command = np.full((self.num_envs, 1), self.cfg["height_command_m"])
        self.last_torque = np.zeros((self.num_envs, 8))
        self.sensors = np.zeros((self.num_envs, self.model.nsensordata))
        self.total_successes = self.total_failures = self.total_timeouts = self.total_physics_faults = 0
        self.reset()

    @property
    def qpos(self) -> np.ndarray:
        return self.state[:, 1 : 1 + self.model.nq]

    @property
    def qvel(self) -> np.ndarray:
        return self.state[:, 1 + self.model.nq : 1 + self.model.nq + self.model.nv]

    def reset_mask(self, mask: np.ndarray) -> None:
        count = int(mask.sum())
        if not count:
            return
        self.state[mask] = self.template
        self.qpos[mask, :2] = self.tile["spawn_xy_m"]
        yaw = self.rng.uniform(*self.cfg["reset_yaw_range_rad"], count)
        self.qpos[mask, 3:7] = np.stack((np.cos(yaw / 2), np.zeros(count), np.zeros(count), np.sin(yaw / 2)), axis=1)
        self.command[mask, 0] = self.rng.uniform(*self.cfg["command_vx_range_m_s"], count)
        self.command[mask, 2] = self.rng.uniform(*self.cfg["command_yaw_range_rad_s"], count)
        ids = np.flatnonzero(mask)
        self.command[ids[self.rng.random(count) < self.cfg["standing_fraction"]]] = 0
        if self.stage["tunnel"]:
            self.command[mask] = [self.stage["forward_command_m_s"], 0, 0]
        self.previous[mask] = 0
        self.motor_effort[mask] = self.motor_rate[mask] = 0
        self.first[mask] = True
        self.roof_touched[mask] = False
        self.cleared_tunnel[mask] = False
        self.previous_min_x[mask] = -np.inf
        self.episode_length_buf[torch.from_numpy(mask)] = 0

    def reset(self) -> tuple[torch.Tensor, dict]:
        self.reset_mask(np.ones(self.num_envs, dtype=bool))
        return self.get_observations()

    def get_observations(self) -> tuple[torch.Tensor, dict]:
        policy = self.profile.policy
        q = self.qpos[:, self.qadr[:6]][:, self.permutation] - self.cfg["q_default_rad"]
        q[:, self.cfg["wheel_indices"]] = 0
        gravity = rotate_inverse(self.qpos[:, 3:7], np.tile([0.0, 0.0, -1.0], (self.num_envs, 1)))
        obs = pack_observation(
            {
                "command": self.command * policy.command_scale,
                "height": self.height_command * policy.height_scale,
                "angular_velocity": self.qvel[:, 3:6] * policy.angular_velocity_scale,
                "gravity": gravity * policy.gravity_scale,
                "joint_position": q * policy.joint_position_scale,
                "joint_velocity": self.qvel[:, self.vadr[:6]][:, self.permutation] * policy.joint_velocity_scale,
                "previous_action": self.previous,
                "mode": np.tile(self.profile.physics.normal_mode, (self.num_envs, 1)),
            }
        )
        return torch.from_numpy(obs), {"observations": {}}

    def step(self, actions: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, dict]:
        raw = actions.detach().cpu().numpy().astype(np.float64)
        if raw.shape != (self.num_envs, 6) or not np.isfinite(raw).all():
            raise ValueError("Training actor output must be finite (N,6)")
        previous = self.previous.copy()
        action = np.clip(raw, -self.profile.policy.action_clip, self.profile.policy.action_clip)
        source_action = action[:, self.inverse_permutation]
        start_x = self.qpos[:, 0].copy()
        faults = np.zeros(self.num_envs, dtype=bool)
        force = np.zeros((self.num_envs, 1, self.model.nv))
        for _ in range(self.cfg["control_hz"] // self.cfg["policy_hz"]):
            self.last_torque, self.motor_effort, self.motor_rate = scut_lowlevel(
                self.profile.physics,
                self.qpos[:, self.qadr],
                self.qvel[:, self.vadr],
                source_action,
                self.motor_effort,
                self.motor_rate,
                self.first,
                self.model.opt.timestep,
            )
            self.first[:] = False
            force[:, 0, self.vadr] = self.last_torque
            state, sensor = self.pool.rollout(
                self.model,
                self.data_pool,
                self.state,
                force,
                control_spec=mujoco.mjtState.mjSTATE_QFRC_APPLIED,
                nstep=1,
            )
            bad = ~np.isfinite(state[:, 0]).all(axis=1) | ~np.isclose(
                state[:, 0, 0] - self.state[:, 0], self.model.opt.timestep, atol=1e-10
            )
            self.state[:] = state[:, 0]
            self.sensors[:] = sensor[:, 0]
            faults |= bad
            self.roof_touched |= self.sensors[:, self.roof_sensor_adr] > 0
            # Report and terminate faults; never feed an invalid simulator state into the next substep.
            self.state[bad] = self.template
            self.motor_effort[bad] = self.motor_rate[bad] = 0
        self.previous[:] = raw
        self.episode_length_buf += 1
        gravity = rotate_inverse(self.qpos[:, 3:7], np.tile([0.0, 0.0, -1.0], (self.num_envs, 1)))
        velocity_b = rotate_inverse(self.qpos[:, 3:7], self.qvel[:, :3])
        failed = (gravity[:, 2] > self.cfg["terminate_gravity_z"]) | (
            self.qpos[:, 2] < self.cfg["terminate_base_height_m"]
        )
        failed |= np.any(np.abs(self.qpos[:, :2] - self.tile["center_xy_m"]) > self.cfg["tile_half_extent_m"], axis=1)
        failed |= faults
        success = np.zeros(self.num_envs, dtype=bool)
        if self.stage["tunnel"]:
            geom_pos = self.sensors[:, self.geom_sensor_adr : self.geom_sensor_adr + 3 * self.geom_count]
            relative = geom_pos.reshape(self.num_envs, -1, 3) - np.array([*self.tile["center_xy_m"], 0])
            t = self.cfg["tunnel_geometry"]
            ground = self.sensors[:, self.wheel_sensor_adr : self.wheel_sensor_adr + 2] > 0
            self.cleared_tunnel |= terms.clear_roof(
                relative,
                self.geom_radii,
                self.previous_min_x,
                ground,
                t["length_m"] / 2,
                t["clearance_m"] + t["roof_thickness_m"],
                t["width_m"],
            )
            self.previous_min_x[:] = (relative[:, :, 0] - self.geom_radii).min(axis=1)
            success = terms.tunnel_success(
                geom_pos.reshape(self.num_envs, -1, 3),
                self.geom_radii,
                self.sensors[:, self.wheel_sensor_adr : self.wheel_sensor_adr + 2],
                self.roof_touched,
                self.tile["landing_x_range_m"],
                self.tile["landing_y_range_m"],
            )
            failed |= self.roof_touched
            success &= ~failed
            success &= self.cleared_tunnel
        timeout = (self.episode_length_buf.numpy() >= self.max_episode_length) & ~failed & ~success
        values = {
            "alive": np.ones(self.num_envs),
            "track_forward": terms.track_forward(velocity_b, self.command, self.cfg["tracking_variance"]),
            "track_yaw": terms.track_yaw(self.qvel[:, 3:6], self.command, self.cfg["tracking_variance"]),
            "upright": terms.upright(gravity),
            "height": terms.height(self.qpos[:, 2], self.height_command[:, 0], self.cfg["height_variance_m2"]),
            "vertical_velocity": terms.vertical_velocity(self.qvel[:, :3]),
            "roll_pitch_velocity": terms.roll_pitch_velocity(self.qvel[:, 3:6]),
            "effort": terms.effort(self.last_torque),
            "action_rate": terms.action_rate(
                action, np.clip(previous, -self.profile.policy.action_clip, self.profile.policy.action_clip)
            ),
        }
        weighted = {name: value * self.cfg["rewards"][name] * self.step_dt for name, value in values.items()}
        reward = sum(weighted.values()) + failed * self.cfg["rewards"]["termination"]
        if self.stage["tunnel"]:
            reward += self.cfg["rewards"]["tunnel_progress"] * (self.qpos[:, 0] - start_x)
            reward += self.cfg["rewards"]["tunnel_success"] * success
        terminal_obs, _ = self.get_observations()
        done = failed | success | timeout
        self.total_failures += int(failed.sum())
        self.total_successes += int(success.sum())
        self.total_timeouts += int(timeout.sum())
        self.total_physics_faults += int(faults.sum())
        self.reset_mask(done)
        obs, extras = self.get_observations()
        extras.update(
            {
                "time_outs": torch.from_numpy(timeout.copy()),
                "terminal_observation": terminal_obs,
                "log": {f"Reward/{k}": torch.tensor(float(v.mean())) for k, v in weighted.items()},
            }
        )
        extras["log"].update(
            {
                "Metrics/failure_fraction": torch.tensor(float(failed.mean())),
                "Metrics/success_fraction": torch.tensor(float(success.mean())),
                "Metrics/physics_faults": torch.tensor(float(faults.sum())),
            }
        )
        return obs, torch.from_numpy(reward.astype(np.float32)), torch.from_numpy(done), extras

    def close(self) -> None:
        self.pool.close()
