"""Vectorized reward rates and conservative tunnel-success geometry, for simulation only."""

import numpy as np


def track_forward(velocity_b: np.ndarray, commands: np.ndarray, variance: float) -> np.ndarray:
    return np.exp(-np.square(velocity_b[:, 0] - commands[:, 0]) / variance)


def track_yaw(angular_velocity_b: np.ndarray, commands: np.ndarray, variance: float) -> np.ndarray:
    return np.exp(-np.square(angular_velocity_b[:, 2] - commands[:, 2]) / variance)


def upright(gravity_b: np.ndarray) -> np.ndarray:
    return np.clip(-gravity_b[:, 2], 0, 1)


def height(base_z: np.ndarray, target: np.ndarray, variance: float) -> np.ndarray:
    return np.exp(-np.square(base_z - target) / variance)


def vertical_velocity(velocity_w: np.ndarray) -> np.ndarray:
    return np.square(velocity_w[:, 2])


def roll_pitch_velocity(angular_velocity_b: np.ndarray) -> np.ndarray:
    return np.square(angular_velocity_b[:, :2]).sum(axis=1)


def effort(torques: np.ndarray) -> np.ndarray:
    return np.square(torques[:, :6]).sum(axis=1)


def action_rate(action: np.ndarray, previous: np.ndarray) -> np.ndarray:
    return np.square(action - previous).sum(axis=1)


def tunnel_success(
    geom_positions: np.ndarray,
    geom_radii: np.ndarray,
    wheel_touch: np.ndarray,
    roof_touched: np.ndarray,
    landing_x: tuple,
    landing_y: tuple,
) -> np.ndarray:
    # Every robot geom's bounding sphere must be wholly inside the rear ground landing zone.
    low = geom_positions - geom_radii[None, :, None]
    high = geom_positions + geom_radii[None, :, None]
    inside = (
        (low[:, :, 0].min(axis=1) > landing_x[0])
        & (high[:, :, 0].max(axis=1) < landing_x[1])
        & (low[:, :, 1].min(axis=1) > landing_y[0])
        & (high[:, :, 1].max(axis=1) < landing_y[1])
    )
    return inside & np.all(wheel_touch > 0, axis=1) & ~roof_touched


def clear_roof(
    positions: np.ndarray,
    radii: np.ndarray,
    previous_min_x: np.ndarray,
    wheel_ground: np.ndarray,
    roof_rear_x: float,
    roof_top_z: float,
    roof_width: float,
) -> np.ndarray:
    low, high = positions - radii[None, :, None], positions + radii[None, :, None]
    return (
        (previous_min_x <= roof_rear_x)
        & (low[:, :, 0].min(axis=1) > roof_rear_x)
        & (low[:, :, 2].min(axis=1) > roof_top_z)
        & (low[:, :, 1].min(axis=1) > -roof_width / 2)
        & (high[:, :, 1].max(axis=1) < roof_width / 2)
        & ~wheel_ground.any(axis=1)
    )
