"""SCUT-only CPU player. No SRM hardware parameters are consumed or changed.

Observation/actions adapted from SCUTRobotLab state_rl.cpp (MIT, © 2025 SCUTRobotLab).
Motor and spring equations adapted from mujoco_system.cpp (MIT, © 2025 Sangtaek Lee,
with SCUTRobotLab modifications). Full notices: docs/SCUT_PLAYER_LICENSES.txt.
"""

import hashlib
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

import mujoco
import numpy as np
import onnxruntime as ort
import yaml

from .observation import OBS_DIM


@dataclass(frozen=True)
class ScutConfig:
    model: Path
    sha256: str
    joint_names: tuple[str, ...]
    parameters: MappingProxyType
    actuator: MappingProxyType
    spring: MappingProxyType
    keyboard: MappingProxyType
    effort_min: tuple[float, ...]
    effort_max: tuple[float, ...]
    normal_mode: tuple[float, ...]


def load_scut_config(path: Path, *, verify_model: bool = True) -> ScutConfig:
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    p, a, s = raw["parameters"], raw["actuator"], raw["spring"]
    sizes = {"cmd": 4, "ang_vel": 3, "gravity": 3, "joint_pos": 6, "joint_vel": 4, "wheel_vel": 2, "action": 6}
    for name, size in sizes.items():
        for suffix in ["scale", "min", "max"]:
            key = f"policy_input_{name}_{suffix}"
            values = np.asarray(p[key])
            if values.shape != (size,) or not np.isfinite(values).all():
                raise ValueError(f"{path}: {key} must contain {size} finite values")
        if np.any(np.asarray(p[f"policy_input_{name}_min"]) > p[f"policy_input_{name}_max"]):
            raise ValueError(f"{path}: {name} observation min exceeds max")
    for key in [
        "joint_stiffness",
        "joint_damping",
        "joint_action_scale",
        "joint_output_min",
        "joint_output_max",
        "joint_bias",
        "default_dof_pos",
    ]:
        if np.shape(p[key]) != (8,) or not np.isfinite(p[key]).all():
            raise ValueError(f"{path}: {key} must contain eight finite values")
    if len(raw["joint_names"]) != 8 or len(set(raw["joint_names"])) != 8:
        raise ValueError(f"{path}: eight distinct joint names required")
    expected = (
        "left_front1_joint",
        "left_rear1_joint",
        "right_front1_joint",
        "right_rear1_joint",
        "left_wheel_joint",
        "right_wheel_joint",
        "left_spring2_joint",
        "right_spring2_joint",
    )
    if tuple(raw["joint_names"]) != expected:
        raise ValueError(f"{path}: joint order must match the SCUT policy contract")
    if np.any(np.asarray(p["joint_stiffness"]) < 0) or np.any(np.asarray(p["joint_damping"]) < 0):
        raise ValueError(f"{path}: PD gains must be nonnegative")
    if raw["normal_mode"] != [1, 0, 0, 0, 0, 0, 0]:
        raise ValueError(f"{path}: only normal-only mode supported")
    if p["rl_inference_frequency"] <= 0 or p["update_rate"] % p["rl_inference_frequency"]:
        raise ValueError(f"{path}: policy frequency must divide control frequency")
    if a["actuator_transport_delay_s"] != 0 or not s["model_enabled"] or not s["manual_passive_enabled"]:
        raise ValueError(f"{path}: expected the original zero-delay actuator and enabled gas spring model")
    for key in [
        "actuator_natural_frequency_hz",
        "actuator_damping_ratio",
        "actuator_torque_slew_rate_nm_s",
        "actuator_output_limit",
    ]:
        if not np.isfinite(a[key]) or a[key] <= 0:
            raise ValueError(f"{path}: {key} must be finite and positive")
    if s["q_max"] <= s["q_min"] or s["manual_velocity_epsilon"] <= 0:
        raise ValueError(f"{path}: invalid spring position span or velocity epsilon")
    if p["lowlevel_output_mode"] != "hardware_pd_vel" or p["rl_action_filter_type"] != "none":
        raise ValueError(f"{path}: only hardware_pd_vel and no action filter supported")
    if p["enable_noise"] or p["enable_delay"]:
        raise ValueError(f"{path}: noise and delay are not supported in this player")
    for key in ["hardware_effort_min", "hardware_effort_max"]:
        if np.shape(raw[key]) != (8,) or not np.isfinite(raw[key]).all():
            raise ValueError(f"{path}: {key} must contain eight finite values")
    if np.any(np.asarray(raw["hardware_effort_min"]) > raw["hardware_effort_max"]):
        raise ValueError(f"{path}: hardware effort min exceeds max")
    if np.any(np.asarray(p["joint_output_min"]) > p["joint_output_max"]):
        raise ValueError(f"{path}: joint output min exceeds max")
    model = (path.parent / raw["model"]).resolve()
    if verify_model and hashlib.sha256(model.read_bytes()).hexdigest() != raw["sha256"]:
        raise ValueError(f"{model}: policy checksum does not match {path}")
    frozen_p = {key: tuple(value) if isinstance(value, list) else value for key, value in p.items()}
    return ScutConfig(
        model,
        raw["sha256"],
        tuple(raw["joint_names"]),
        MappingProxyType(frozen_p),
        MappingProxyType(a),
        MappingProxyType(s),
        MappingProxyType(raw["keyboard"]),
        tuple(raw["hardware_effort_min"]),
        tuple(raw["hardware_effort_max"]),
        tuple(raw["normal_mode"]),
    )


def scut_observation(
    cfg: ScutConfig,
    command: np.ndarray,
    gyro_b: np.ndarray,
    gravity_b: np.ndarray,
    q: np.ndarray,
    dq: np.ndarray,
    previous: np.ndarray,
) -> np.ndarray:
    for value, size in [(command, 4), (gyro_b, 3), (gravity_b, 3), (q, 8), (dq, 8), (previous, 6)]:
        if value.shape != (size,) or not np.isfinite(value).all():
            raise ValueError("SCUT observation requires finite 35D input components of the specified sizes")
    p = cfg.parameters
    parts = [
        ("cmd", command),
        ("ang_vel", gyro_b),
        ("gravity", gravity_b),
        ("joint_pos", np.concatenate((q[:4], np.zeros(2)))),
        ("joint_vel", dq[:4]),
        ("wheel_vel", dq[4:6]),
        ("action", previous),
    ]
    obs = np.concatenate(
        [
            np.clip(
                values * p[f"policy_input_{name}_scale"], p[f"policy_input_{name}_min"], p[f"policy_input_{name}_max"]
            )
            for name, values in parts
        ]
        + [cfg.normal_mode]
    )
    if obs.shape != (OBS_DIM,) or not np.isfinite(obs).all():
        raise ValueError("SCUT observation must be a finite 35D vector")
    return obs.astype(np.float32)[None, :]


def spring_force(cfg: ScutConfig, position: np.ndarray, velocity: np.ndarray) -> np.ndarray:
    s = cfg.spring
    ratio = (np.clip(position, s["q_min"], s["q_max"]) - s["q_min"]) / (s["q_max"] - s["q_min"])
    return (
        s["force_at_q_min"]
        + (s["force_at_q_max"] - s["force_at_q_min"]) * ratio
        - s["manual_viscous_damping"] * velocity
        - s["manual_static_friction"] * np.tanh(velocity / s["manual_velocity_epsilon"])
    )


def motor_step(
    cfg: ScutConfig, requested: np.ndarray, velocity: np.ndarray, effort: np.ndarray, rate: np.ndarray, dt: float
) -> tuple[np.ndarray, np.ndarray]:
    a = cfg.actuator
    droop = np.maximum(0, np.abs(velocity) - a["actuator_speed_droop_start_rad_s"])
    gain = np.clip(1 - a["actuator_speed_droop_per_rad_s"] * droop, a["actuator_min_speed_gain"], 1)
    target = a["actuator_dc_gain"] * gain * requested
    wn = 2 * np.pi * a["actuator_natural_frequency_hz"]
    acceleration = wn**2 * (target - effort) - 2 * a["actuator_damping_ratio"] * wn * rate
    rate = np.clip(rate + dt * acceleration, -a["actuator_torque_slew_rate_nm_s"], a["actuator_torque_slew_rate_nm_s"])
    raw = effort + dt * rate
    effort = np.clip(raw, -a["actuator_output_limit"], a["actuator_output_limit"])
    rate = np.where((effort != raw) & (effort * rate > 0), 0, rate)
    return effort, rate


def scut_lowlevel(
    cfg: ScutConfig,
    q: np.ndarray,
    dq: np.ndarray,
    action: np.ndarray,
    effort: np.ndarray,
    rate: np.ndarray,
    first: np.ndarray,
    dt: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Batched upstream forces; q/dq (...,8), source-order action (...,6)."""
    p = cfg.parameters
    target = action * np.asarray(p["joint_action_scale"][:6]) + p["default_dof_pos"][:6]
    error = (target[..., :4] - q[..., :4] + np.pi) % (2 * np.pi) - np.pi
    requested = np.zeros(q.shape)
    requested[..., :4] = np.asarray(p["joint_stiffness"][:4]) * error - np.asarray(p["joint_damping"][:4]) * dq[..., :4]
    requested[..., 4:6] = np.asarray(p["joint_damping"][4:6]) * (target[..., 4:6] - dq[..., 4:6])
    requested += p["joint_bias"]
    requested = np.clip(requested, p["joint_output_min"], p["joint_output_max"])
    requested[..., 6:8] += spring_force(cfg, q[..., 6:8], dq[..., 6:8])
    requested = np.clip(requested, cfg.effort_min, cfg.effort_max)
    effort = np.where(np.asarray(first)[..., None], cfg.actuator["actuator_dc_gain"] * requested[..., :4], effort)
    effort, rate = motor_step(cfg, requested[..., :4], dq[..., :4], effort, rate, dt)
    requested[..., :4] = effort
    if not np.isfinite(requested).all():
        raise ValueError("Non-finite motor/spring output; simulation stopped")
    return requested, effort, rate


class ScutController:
    def __init__(self, model: mujoco.MjModel, cfg: ScutConfig) -> None:
        self.cfg, self.model = cfg, model
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        self.session = ort.InferenceSession(str(cfg.model), options, providers=["CPUExecutionProvider"])
        inputs, outputs = self.session.get_inputs(), self.session.get_outputs()
        if (
            len(inputs) != 1
            or len(outputs) != 1
            or inputs[0].name != "obs"
            or outputs[0].name != "actions"
            or inputs[0].shape != [1, 35]
            or outputs[0].shape != [1, 6]
            or inputs[0].type != "tensor(float)"
            or outputs[0].type != "tensor(float)"
        ):
            raise ValueError("Expected ONNX obs float32[1,35] -> actions float32[1,6]")
        joint_ids = [mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name) for name in cfg.joint_names]
        self.site = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "base_link_site")
        if min(joint_ids) < 0 or self.site < 0:
            raise ValueError("Scene does not contain the eight SCUT joints and base_link_site")
        self.qadr, self.vadr = model.jnt_qposadr[joint_ids], model.jnt_dofadr[joint_ids]
        dt = 1 / cfg.parameters["update_rate"]
        if not np.isclose(model.opt.timestep, dt, rtol=0, atol=1e-12):
            raise ValueError(f"Scene timestep must be {dt} s")
        self.decimation = cfg.parameters["update_rate"] // cfg.parameters["rl_inference_frequency"]
        self.reset()

    def reset(self) -> None:
        self.action = np.zeros(6, dtype=np.float32)
        self.effort, self.rate = np.zeros(4), np.zeros(4)
        self.steps = 0
        self.observation = np.zeros((1, 35), dtype=np.float32)

    def observe(self, data: mujoco.MjData, command: np.ndarray) -> np.ndarray:
        velocity = np.zeros(6)
        mujoco.mj_objectVelocity(self.model, data, mujoco.mjtObj.mjOBJ_SITE, self.site, velocity, 1)
        gravity = data.site_xmat[self.site].reshape(3, 3).T @ np.array([0.0, 0.0, -1.0])
        # Match upstream signed angle wrapping; the spring positions stay in their small SI range.
        q = np.fmod(data.qpos[self.qadr], 2 * np.pi)
        q = np.where(q > np.pi, q - 2 * np.pi, np.where(q < -np.pi, q + 2 * np.pi, q))
        return scut_observation(self.cfg, command, velocity[:3], gravity, q, data.qvel[self.vadr], self.action)

    def step(self, data: mujoco.MjData, command: np.ndarray) -> bool:
        inferred = self.steps % self.decimation == 0
        if inferred:
            self.observation = self.observe(data, command)
            action = self.session.run(["actions"], {"obs": self.observation})[0]
            if action.shape != (1, 6) or not np.isfinite(action).all():
                raise ValueError("ONNX produced an invalid action; simulation stopped")
            self.action = action[0].copy()
        q, dq = data.qpos[self.qadr], data.qvel[self.vadr]
        requested, self.effort, self.rate = scut_lowlevel(
            self.cfg, q, dq, self.action, self.effort, self.rate, np.asarray(self.steps == 0), self.model.opt.timestep
        )
        # Upstream bridge writes generalized forces; do not also send them through the MJCF motors.
        data.ctrl[:] = 0
        data.qfrc_applied[:] = 0
        data.qfrc_applied[self.vadr] = requested
        self.steps += 1
        return inferred
